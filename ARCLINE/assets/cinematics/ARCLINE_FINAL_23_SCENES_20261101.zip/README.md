# ARCLINE final selected cinematic shots

All 23 shot IDs have one selected JPEG in assets/cinematics/.
P01-03 uses a working harbor exterior with lit workshop rather than a workshop interior close-up.
E01-03 and E04-01 are the newly approved replacements.
manifest.csv records source filenames and SHA-256 hashes.
GitHub binary upload is separate from this local delivery package.
