from art_core import Scene

def make():
 s=Scene('boss-090','スカイキャリア — 嵐の上甲板',17,'遠望した嵐の空母へ近づき、上甲板から雲海を望む。左の近い艦橋、広い冷たい甲板、右端の係留設備。戦うスカイキャリアを別の船体として背景へ複製しない。',{
 'sky':'#A7B7C7','gap':'#D2C5AC','gapLit':'#E0D2B5','cloud':'#859BB2','cloudShade':'#6C88A5','cloudDeep':'#567592','cloudLight':'#BAC7CD',
 'hull':'#718CA4','hullLit':'#9AAEB7','hullShade':'#59758F','deep':'#465F7C','glass':'#617E98','glassLit':'#A9B7B5',
 'brass':'#ADA185','deck':'#91A5B3','deckLit':'#B3BDBB','deckShade':'#708BA4','steel':'#78909E','steelLit':'#A1B1B2','steelShade':'#58768C'})
 s.base()
 s.p('gap','M301 221 C357 151 425 164 486 149 C552 134 589 145 653 124 C751 94 817 132 868 123 C764 194 733 212 701 266 C558 282 434 266 344 294 C326 273 320 245 301 221 Z','air')
 s.p('gapLit','M408 218 C480 172 535 187 594 176 C664 153 739 165 798 154 C750 185 727 208 707 228 C610 240 507 232 475 253 C452 245 430 234 408 218 Z','air')
 s.p('cloud','M0 349 C163 302 273 344 412 308 C616 253 760 317 903 275 C1001 247 1079 281 1120 267 V604 H0 Z','far')
 s.p('cloudLight','M236 419 C365 378 465 427 587 396 C778 349 944 410 1120 366 V604 H0 Z','middle')
 s.p('cloudShade','M0 0 H1120 V160 C1057 144 1005 175 950 151 C895 130 849 165 806 148 C734 134 708 167 657 154 C589 132 551 167 498 150 C422 125 391 155 346 137 C233 110 132 153 0 119 Z','air')
 s.p('cloudDeep','M0 0 H1120 V84 C1029 58 956 103 883 77 C799 48 742 94 665 70 C567 39 506 90 423 61 C313 28 207 79 127 56 L0 72 Z','air')
 # Close architecture on the same carrier, no second boss-shaped hull.
 s.p('hull','M0 165 L145 143 L239 182 L254 437 L0 480 Z','land')
 s.p('hullShade','M145 143 L239 182 L254 437 L195 450 L174 259 Z','land')
 s.p('hullLit','M0 165 L145 143 L239 182 L218 190 L146 166 L0 188 Z','land')
 s.p('deep','M0 237 L174 217 L180 264 L0 286 Z','structure')
 s.p('glass','M0 247 L164 230 L168 256 L0 275 Z','structure')
 s.p('glassLit','M58 240 L66 239 L69 267 L61 268 Z','structure')
 s.p('glassLit','M119 234 L127 233 L130 260 L122 261 Z','structure')
 s.p('brass','M0 307 L184 286 L187 300 L0 324 Z','structure')
 s.p('hullShade','M0 400 L193 376 L200 402 L0 430 Z','structure')
 s.p('hull','M51 155 L46 78 L98 64 L126 81 L134 156 Z','structure')
 s.p('hullLit','M46 78 L98 64 L126 81 L112 88 L96 79 L57 91 Z','structure')
 s.p('hullShade','M98 64 L126 81 L134 156 L104 160 Z','structure')
 s.p('deck','M0 489 L258 443 L535 462 L842 417 L1120 446 V604 H0 Z','land')
 s.p('deckLit','M0 489 L258 443 L535 462 L842 417 L1120 446 V459 L845 435 L536 481 L261 462 L0 510 Z','land')
 s.p('deckShade','M0 580 L276 532 L531 553 L854 503 L1120 525 V604 H0 Z','land')
 s.p('steel','M1026 0 H1054 L1006 328 L1041 481 L1016 487 L980 328 Z','structure')
 s.p('steelLit','M1026 0 H1035 L991 328 L1027 485 L1016 487 L980 328 Z','structure')
 s.p('steelShade','M1000 294 L1120 243 V271 L1003 321 Z','structure')
 s.p('brass','M1000 294 L1120 243 V253 L1001 306 Z','structure')
 s.p('steelShade','M969 475 L1046 459 L1120 475 V522 L988 531 Z','structure')
 s.p('steelLit','M969 475 L1046 459 L1120 475 V487 L1046 475 L981 490 Z','structure')
 s.p('deep','M0 604 V575 L120 548 L227 580 L255 604 Z','near')
 s.p('steelShade','M1120 561 L1047 540 L963 574 L938 604 H1120 Z','near')
 s.data.update(kind='boss',stage=90)
 return s.data
