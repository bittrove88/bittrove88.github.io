from art_core import Scene

def make():
 s=Scene('normal-05','雲の空港',5,'澄んだ昼空に浮かぶ空港。赤い蒲鉾屋根の格納庫、黄土色の管制塔、雲へ伸びる係留桟橋。空港の建物は左下へまとめ、空の広さと白い雲海を主役にする。',{
 'sky':'#AFCFE5','blueHigh':'#94BAD9','blueOpen':'#C7DFEC','cloud':'#F4EEDC','cloudLit':'#FFF5E0','cloudShade':'#CED7DE',
 'cloudBlue':'#B7CBDA','cloudDeep':'#9CB7CB','hangar':'#C7836B','roof':'#D99576','roofLit':'#EDB58D','roofShade':'#AF7768',
 'steel':'#8A9FA5','steelLit':'#C3CDC6','steelShade':'#6E8794','door':'#758C9C','doorLit':'#9AAEB8',
 'deck':'#C7BC9D','deckLit':'#E4D4AE','deckShade':'#A3A893','tower':'#C5AA79','towerLit':'#E3C99A','towerShade':'#A18C6B',
 'glass':'#819EAF','glassShade':'#607F99','flag':'#D7A05E','flagLit':'#F0C285','near':'#9FB8C8'})
 s.base()
 s.p('blueHigh','M0 0 H1120 V172 C962 182 833 144 697 153 C510 166 325 129 0 159 Z','air')
 s.p('blueOpen','M0 295 C172 277 347 293 462 268 C644 234 798 281 966 258 C1041 248 1098 251 1120 245 V604 H0 Z','air')
 s.p('cloudShade','M0 341 C45 302 100 318 122 341 C145 300 200 306 220 337 C256 324 282 345 284 367 C331 348 361 368 371 394 L0 432 Z','far')
 s.p('cloud','M789 278 C820 237 872 257 889 280 C923 237 978 249 995 280 C1033 260 1060 287 1064 309 C1083 300 1107 305 1120 316 V387 C1006 401 875 380 816 390 C776 385 751 329 789 278 Z','far')
 s.p('cloudLit','M849 264 C877 249 888 266 900 274 C926 251 956 259 965 276 C993 269 1012 286 1016 302 C955 294 914 309 870 291 Z','far')
 s.p('cloudBlue','M0 442 C144 398 232 451 378 419 C523 387 647 433 777 400 C924 361 1020 407 1120 384 V604 H0 Z','middle')
 # A low hangar and sloping apron, not an arch flanked by towers.
 s.p('deck','M0 430 L266 383 L607 429 L769 475 L645 509 L140 494 L0 473 Z','land')
 s.p('deckLit','M0 430 L266 383 L607 429 L676 448 L321 414 L95 453 L0 454 Z','land')
 s.p('deckShade','M0 473 L140 494 L645 509 L769 475 L752 499 L643 532 L142 518 L0 494 Z','land')
 s.p('steelShade','M180 515 L212 516 L226 554 L205 562 Z','back-structure')
 s.p('steelShade','M576 528 L609 526 L600 566 L578 570 Z','back-structure')
 s.p('roofShade','M231 249 L319 221 C386 248 411 288 410 333 L306 377 L306 337 C306 311 285 271 231 249 Z','structure')
 s.p('roof','M231 249 L319 221 C355 236 385 260 398 285 L293 304 C281 279 257 260 231 249 Z','structure')
 s.p('hangar','M31 336 C46 242 142 215 231 249 C285 271 306 311 306 377 L45 424 Z','structure')
 s.p('roof','M31 336 C46 242 142 215 231 249 C285 271 306 311 306 337 L278 340 C268 295 230 275 184 277 C126 278 76 305 67 340 Z','structure')
 s.p('roofLit','M31 336 C46 242 142 215 231 249 C263 262 284 285 294 304 C251 264 199 251 153 260 C95 269 59 303 49 338 Z','structure')
 s.p('roofShade','M231 249 C285 271 306 311 306 337 L278 340 C268 295 230 275 184 277 L181 261 Z','structure')
 s.p('steelShade','M68 344 C83 290 152 270 211 294 C244 307 264 331 268 356 L270 386 L79 418 Z','structure')
 s.p('door','M85 347 C103 304 153 294 199 309 C227 318 244 339 248 362 L249 388 L93 414 Z','structure')
 s.p('doorLit','M95 349 C114 318 147 308 174 313 L175 402 L93 414 Z','structure')
 s.p('steel','M172 312 L180 315 L181 401 L174 402 Z','structure')
 s.p('steelLit','M44 341 L67 338 L80 418 L59 422 Z','structure')
 s.p('steel','M268 356 L286 346 L290 383 L270 386 Z','structure')
 s.p('tower','M804 300 L839 295 L852 421 L821 429 Z','back-structure')
 s.p('towerShade','M839 295 L860 305 L872 415 L852 421 Z','back-structure')
 s.p('towerLit','M785 270 L823 259 L872 273 L854 284 L794 286 Z','back-structure')
 s.p('glass','M794 286 L854 284 L860 305 L804 310 Z','back-structure')
 s.p('glassShade','M854 284 L876 278 L879 298 L860 305 Z','back-structure')
 s.p('steelShade','M798 282 L804 281 L809 309 L803 310 Z','back-structure')
 s.p('steelShade','M829 283 H835 L837 306 L831 307 Z','back-structure')
 s.p('towerLit','M821 313 L830 311 L841 421 L833 424 Z','back-structure')
 s.p('deck','M732 427 L890 402 L984 427 L826 459 Z','back-structure')
 s.p('deckShade','M732 427 L826 459 L984 427 V442 L825 476 L732 443 Z','back-structure')
 s.p('steelShade','M732 443 L825 476 L984 442 L944 476 L856 506 L794 497 Z','back-structure')
 s.p('steel','M681 312 H688 V457 L681 455 Z','structure')
 s.p('flag','M688 316 L744 303 L765 313 L745 330 L688 331 Z','structure')
 s.p('flagLit','M688 316 L744 303 L765 313 L743 320 L688 324 Z','structure')
 s.p('cloud','M0 521 C73 481 141 528 211 502 C280 475 334 514 370 524 C426 497 477 524 505 546 C570 516 631 549 666 554 C752 516 804 553 879 528 C957 502 1040 548 1120 510 V604 H0 Z','near')
 s.p('cloudLit','M0 518 C72 489 133 527 211 502 C255 486 296 498 319 512 C241 526 175 531 117 546 C62 541 36 548 0 539 Z','near')
 s.p('cloudShade','M0 579 C113 548 219 590 332 560 C459 533 550 583 655 561 C825 526 958 581 1120 548 V604 H0 Z','near')
 s.p('cloudBlue','M0 603 C179 565 310 611 485 582 C698 552 873 606 1120 575 V604 H0 Z','finish')
 return s.data
