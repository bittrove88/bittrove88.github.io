"""ARCLINE 効果音 再制作計画 v1.0 Gate 3：10機の通し確認（発射→固有現象→着弾の模擬連結）。

音は現在の最良版（Gate 1・2 で採用した r1 ＋ そのほかの現行版）。
各場面は、game/dist/physics.js が出すイベント（impact／critical／airburst／shockwave／breach-pulse／break／
bounce／split／roll／roll-fall／pull／compression）の順序と、combat.js の定数（ハナ 0.18 秒、モグ 0.22 秒、
ユイ 0.6 秒、コロ最長 600px÷220px/s≒2.7 秒、リコ最大 4 回、ソラ 8 分裂）に合わせた模擬のイベント列で鳴らす。
飛翔時間・跳弾の間隔・分裂の高さなどは試聴用の仮の値（実際の物理計算の値ではない）。
使い方: python gate3_run_through.py <出力先> <dec フォルダ> <ラウドネス基準の wav> <download_o>
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402
import soundfile as sf  # noqa: E402
from arcline_sfx_lib import SR, LEVEL_DB, k_weight, loud_db, overlay, match_loudness, encode_m4a  # noqa: E402
from phaseD_specials import s03_roll, resample, pan  # noqa: E402

G = 0.65 * 10 ** (LEVEL_DB / 20)


def load_sounds(base, target):
    final = base / 'ARCLINE_SFX_FINAL' / 'sounds'
    g1 = base / 'ARCLINE_SFX_rework_gate1' / 'sounds'
    g2 = base / 'ARCLINE_SFX_rework_gate2' / 'sounds'
    comp = {'F-01_power_strong_r1': 4.1, 'I-04_Fracture_Hit_r1': 1.7, 'S-05_Core_Compression_r1': 0.2}
    comp.update(json.loads((base / 'ARCLINE_SFX_rework_gate2' / '再生補正.json').read_text(encoding='utf-8')))

    def rd(p):
        w = sf.read(p, dtype='float64')[0]
        return w * 10 ** (comp.get(p.stem, 0) / 20)  # 旧版と同じ大きさで鳴らす
    S = {
        'F-01': rd(final / 'F_fire/F-01_Sharp_Pulse_S3L.wav'), 'F-02': rd(final / 'F_fire/F-02_Dark_Pulse.wav'),
        'F-03': rd(final / 'F_fire/F-03_Heavy_Actuator.wav'),
        'I-01': rd(final / 'I_impact/I-01_Hard_Contact.wav'), 'I-02': rd(final / 'I_impact/I-02_Armor_Slam.wav'),
        'I-03': rd(final / 'I_impact/I-03_Plasma_Snap.wav'), 'I-03air': rd(final / 'I_impact/I-03_airburst_variant_hibari.wav'),
        'I-04': rd(g1 / 'I-04_Fracture_Hit_r1.wav'), 'I-05': rd(final / 'I_impact/I-05_Pressure_Impact.wav'),
        'D-01': rd(final / 'D_debris/D-01_Debris_Break.wav'),
        'S-01': rd(final / 'S_special/S-01_Pressure_Wave.wav'), 'S-02': rd(final / 'S_special/S-02_Meteor_Split.wav'),
        'S-03roll1.2': rd(final / 'S_special/S-03_Rolling_Drive_1.2s.wav'),
        'S-03roll1.4': match_loudness(s03_roll(1.4, 1210), target, -4.0, ceiling=99),  # 段階Dと同じ作り方
        'S-03fall': rd(final / 'S_special/S-03_Roll_Fall.wav'), 'S-04': rd(final / 'S_special/S-04_Gravity_Pull.wav'),
        'S-05': rd(g1 / 'S-05_Core_Compression_r1.wav'), 'S-06': rd(final / 'S_special/S-06_Pinpoint_Break.wav'),
        'rico_final': rd(final / 'R_ricochet/I-01_I-02_Rico_final_blend.wav'),
    }
    for k in range(1, 5):
        S[f'R-01rico{k}'] = rd(final / f'R_ricochet/R-01_Rico_bounce{k}.wav')
    for m in ('gun', 'ban', 'mogu', 'koro'):
        S[f'fire_{m}'] = rd(g2 / f'SP_fire_{m}_r1.wav')
    for m in ('hibari', 'rin', 'sora', 'rico', 'yui', 'hana_1', 'hana_2', 'hana_3'):
        S[f'fire_{m}'] = rd(final / f'SP_fire/SP_fire_{m}.wav')
    return S


def timelines(S):
    """場面ごとのイベント列：(時刻, 物理イベント名, 音, 音量dB)。音は S のキー、または音源そのもの。"""
    rng = np.random.default_rng(77)
    T = {}
    T['通常弾と敵の発射'] = [(1.00, '発射（自機の通常弾）', 'F-01', 0), (1.80, 'impact', 'I-01', 0),
                         (2.60, '発射（敵の通常弾）', 'F-02', 0), (3.40, 'impact（被弾）', 'I-01', 0),
                         (4.20, '発射（敵の重量弾）', 'F-03', 0), (5.00, 'impact（被弾）', 'I-02', 0)]
    T['ガン'] = [(1.05, '発射', 'fire_gun', 0), (2.05, 'impact', 'I-02', 0), (2.065, 'break', 'D-01', -3),
               (3.60, '発射', 'fire_gun', 0), (4.60, 'impact（壊れない）', 'I-02', 0)]
    T['バン'] = [(1.05, '発射', 'fire_ban', 0), (1.85, 'impact', 'I-05', 0), (1.855, 'shockwave', 'S-01', 0),
               (3.60, '発射', 'fire_ban', 0), (4.40, 'impact', 'I-05', 0), (4.405, 'shockwave', 'S-01', 0)]
    T['ヒバリ'] = [(1.05, '発射', 'fire_hibari', 0), (1.75, 'airburst（接触前に起爆）', 'I-03air', 0),
                (3.60, '発射', 'fire_hibari', 0), (4.40, 'impact（近接起爆せず接触）', 'I-03', 0)]
    ev = []
    for base in (1.05, 3.60):
        for k, d in enumerate((0.0, 0.18, 0.36)):
            ev += [(base + d, f'発射（{k + 1}発目、{d:.2f}秒）', f'fire_hana_{k + 1}', 0),
                   (base + 0.80 + d, 'impact', resample(S['I-01'], (0.97, 1.0, 1.03)[k]), -1.5)]
    T['ハナ'] = ev
    T['リン'] = [(1.05, '発射', 'fire_rin', 0), (1.45, 'impact（中心を外れた）', 'I-03', 0),
               (2.90, '発射', 'fire_rin', 0), (3.30, 'critical', 'I-03', -3), (3.30, 'critical', 'S-06', 0),
               (4.75, '発射', 'fire_rin', 0), (5.15, 'critical', 'I-03', -3), (5.15, 'critical', 'S-06', 0)]
    ev = []
    for base in (1.05, 3.80):
        ev += [(base, '発射', 'fire_mogu', 0), (base + 0.80, 'impact', 'I-04', -3),
               (base + 1.02, 'breach-pulse（0.22秒後）', 'I-04', -2), (base + 1.24, 'breach-pulse（0.44秒後）', 'I-04', 0),
               (base + 1.255, 'break', 'D-01', -3)]
    T['モグ'] = ev
    T['コロ'] = [(0.60, '発射', 'fire_koro', 0), (1.30, 'roll（着地）', 'I-01', -10), (1.30, 'roll（転走 1.2秒）', 'S-03roll1.2', 0),
               (2.50, 'roll-fall（段差から落下）', 'S-03fall', 0), (2.85, 'roll（再着地）', 'I-01', -10),
               (2.85, 'roll（再転走 1.4秒）', 'S-03roll1.4', 0), (4.25, 'impact（転走の上限で爆発、転走音は止まる）', 'I-02', 0)]
    ev = []
    for base in (0.90, 3.70):
        ev += [(base, '発射', 'fire_sora', 0), (base + 0.85, 'split（頂点で8分裂）', 'S-02', 0)]
        for c in range(8):
            child = pan(resample(S['I-01'], rng.uniform(0.93, 1.08)), -0.7 + 1.4 * c / 7)
            ev += [(base + 1.40 + rng.uniform(0, 0.28), f'impact（子弾{c + 1}）', child, -11)]
    T['ソラ'] = ev
    T['リコ'] = [(0.50, '発射', 'fire_rico', 0), (1.05, 'bounce count=1', 'R-01rico1', 0), (1.60, 'bounce count=2', 'R-01rico2', 0),
               (2.15, 'impact（2回跳ねて着弾）', 'I-01', 0),
               (3.00, '発射', 'fire_rico', 0), (3.50, 'bounce count=1', 'R-01rico1', 0), (4.00, 'bounce count=2', 'R-01rico2', 0),
               (4.50, 'bounce count=3', 'R-01rico3', 0), (5.00, 'bounce count=4', 'R-01rico4', 0),
               (5.50, 'impact（4回跳ねた最終着弾）', 'rico_final', 0)]
    T['ユイ'] = [(0.70, '発射', 'fire_yui', 0), (1.40, 'impact（接触、控えめ）', 'I-05', -4), (1.40, 'pull（0.6秒）', 'S-04', 0),
               (2.00, 'compression（I-05 は重ねない）', 'S-05', 0),
               (3.60, '発射', 'fire_yui', 0), (4.30, 'impact（接触、控えめ）', 'I-05', -4), (4.30, 'pull（0.6秒）', 'S-04', 0),
               (4.90, 'compression（I-05 は重ねない）', 'S-05', 0)]
    T['似ている発射：ヒバリとリコ'] = [(1.00, '発射（ヒバリ）', 'fire_hibari', 0), (2.30, '発射（リコ）', 'fire_rico', 0),
                              (3.60, '発射（ヒバリ）', 'fire_hibari', 0), (4.90, '発射（リコ）', 'fire_rico', 0)]
    T['似ている発射：ハナ1発目とユイ'] = [(1.00, '発射（ハナ1発目）', 'fire_hana_1', 0), (2.30, '発射（ユイ）', 'fire_yui', 0),
                                (3.60, '発射（ハナ1発目）', 'fire_hana_1', 0), (4.90, '発射（ユイ）', 'fire_yui', 0)]
    return T


def render(seg, events, S):
    v = seg.copy()
    for at, _, snd, g in events:
        w = S[snd] if isinstance(snd, str) else snd
        overlay(v, w * G * 10 ** (g / 20), at)
    return v


def loud_window(x, win=0.4):
    p = np.sum(k_weight(x) ** 2, axis=1); w = int(win * SR)
    return -0.691 + 10 * np.log10(np.convolve(p, np.ones(w) / w, 'valid').max() + 1e-12)


def main():
    out = Path(sys.argv[1]); dec = Path(sys.argv[2]); ref_path = sys.argv[3]; base = Path(sys.argv[4])
    out.mkdir(parents=True, exist_ok=True)
    target = loud_db(sf.read(ref_path, dtype='float64')[0])
    S = load_sounds(base, target)
    T = timelines(S)
    rd = lambda n: sf.read(dec / f'{n}.wav', dtype='float64')[0]  # noqa: E731
    a = rd('bgm_battle_a_original')
    gA = 0.42 / np.abs(a[int(55 * SR):int(61.7 * SR)]).max()  # ゲームと同じく、全曲に同じ固定の音量をかける
    secA = a[int(55 * SR):int(61.7 * SR)] * gA
    c = rd('bgm_battle_c_original')
    c0 = 153.6  # BGM C の最も厚い 6.7 秒（gate3 の BGM 比較で特定）
    secC = c[int(c0 * SR):int((c0 + 6.7) * SR)] * gA

    files = {
        '01_10機_前半_BGM_A_55秒区間': (secA, ['通常弾と敵の発射', 'ガン', 'バン', 'ヒバリ', 'ハナ', 'リン']),
        '02_10機_後半_BGM_A_55秒区間': (secA, ['モグ', 'コロ', 'ソラ', 'リコ', 'ユイ', '似ている発射：ヒバリとリコ',
                                       '似ている発射：ハナ1発目とユイ']),
        '03_要注意_BGM_C_最も厚い区間': (secC, ['通常弾と敵の発射', 'ヒバリ', 'バン', 'モグ', 'コロ', 'リコ', 'ユイ']),
    }
    gap = np.zeros((int(0.45 * SR), 2))
    for name, (seg, keys) in files.items():
        chunks, pos = [], 0.0
        for k in keys:
            v = render(seg, T[k], S)
            pk = float(np.abs(v).max())
            print(f'{name} | {pos:5.2f}s {k}: peak {pk:.3f}' + ('  -> normalized' if pk > 0.95 else ''))
            if pk > 0.95:
                v = v * 0.95 / pk
            chunks += [v, gap]
            pos += (len(v) + len(gap)) / SR
        encode_m4a(np.concatenate(chunks), out / f'{name}.m4a', out)

    # 多重再生の音量上昇（BGMなし）：ハナ3発・ソラ8発・モグ3パルスを、単発と比べる
    def sfx_only(events, keys_only=None):
        v = np.zeros((int(7 * SR), 2))
        for at, ev, snd, g in events:
            if keys_only and not keys_only(ev):
                continue
            w = S[snd] if isinstance(snd, str) else snd
            overlay(v, w * 10 ** (g / 20), at)
        return v
    single_i01 = loud_window(S['I-01']); single_i04 = loud_window(S['I-04'])
    hana = sfx_only(T['ハナ'][:6], lambda e: e == 'impact')
    sora = sfx_only(T['ソラ'][:10], lambda e: e.startswith('impact'))
    mogu = sfx_only(T['モグ'][:4], lambda e: 'impact' in e or 'breach' in e)
    print(f'多重再生（400ms窓のラウドネス）：ハナ3発の着弾 {loud_window(hana) - single_i01:+.1f}dB（I-01 単発比）、'
          f'ソラ8発の子弾 {loud_window(sora) - single_i01:+.1f}dB（I-01 単発比）、'
          f'モグ3パルス {loud_window(mogu) - single_i04:+.1f}dB（I-04 単発比）')
    # README 用のイベント列
    with open(out / 'イベント列.json', 'w', encoding='utf-8') as fh:
        json.dump({k: [(round(at, 3), ev, snd if isinstance(snd, str) else 'I-01（音程・定位を変えた子弾）', g)
                       for at, ev, snd, g in v] for k, v in T.items()}, fh, ensure_ascii=False, indent=1)


if __name__ == '__main__':
    main()
