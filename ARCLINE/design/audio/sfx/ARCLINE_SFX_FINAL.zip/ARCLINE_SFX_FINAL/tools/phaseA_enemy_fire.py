"""ARCLINE 効果音 段階A：敵の発射 F-02〜F-04。

F-01（S3L）と同じ「一発＝一音」の重ね方で作り、立ち上がりの乾き方・倍音の密度・帯域の重心で区別する。
使い方: python phaseA_enemy_fire.py <出力先> <BGM A の wav> <ラウドネス基準の wav>
"""
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402
import soundfile as sf  # noqa: E402
from arcline_sfx_lib import (SR, LEVEL_DB, rms, env, sweep_phase, bp, lp, noise, sat, crush, crackle,  # noqa: E402
                             resonant_lp_sweep, finish, s3_plasma_blaster, loud_db, band_share, re_rise,
                             length_to, write, overlay)


def saw(t, f0, f1, tau):
    ph = sweep_phase(t, f0, f1, tau) / (2 * np.pi)
    return 2 * (ph % 1.0) - 1


def f02_dark_pulse(dur=0.40):
    """F-02 ダーク・パルス「ヴシュッ」：F-01 より暗く鈍い発音。中低域の圧力と、低い機械駆動の唸り。"""
    n = int(dur * SR); t = np.arange(n) / SR
    # 立ち上がりを F-01 より鈍く（0.6ms）、高域を落とした乾かない破裂音
    crack = sat(lp(noise(n, 501, 700, 6000), 5000) * env(t, 0.0006, 0.005, 1.0) * 0.5, 2.5)
    # 機械の駆動：低い鋸波の束を 38Hz で揺らし、中低域に寄せる（音程の下降はごくわずか）
    growl = sum(saw(t, 118 * (1 + d), 96 * (1 + d), 0.03) for d in (-0.02, 0.0, 0.017, 0.035))
    growl = lp(growl, 1400) * (1 + 0.25 * np.sin(2 * np.pi * 38 * t)) * env(t, 0.0006, 0.055, 1.2)
    growl = sat(growl / max(np.abs(growl).max(), 1e-9) * 0.7, 2.6)
    press = sat(noise(n, 502, 180, 1600) * env(t, 0.0005, 0.040, 1.2) * 0.45, 2.4)
    grit = bp(crush(noise(n, 503) * 0.3, 5, 4), 1500, 5000) * env(t, 0.0006, 0.035, 1.1)
    grit /= max(rms(grit[:int(0.03 * SR)]), 1e-9)
    thump = sat(np.sin(sweep_phase(t, 130, 58, 0.010)) * env(t, 0.0008, 0.055, 1.3), 2.0)
    mono = 0.75 * crack + 0.50 * growl + 0.80 * press + 0.18 * grit + 0.70 * thump
    return finish(mono, t, 505, rt60=0.30, predelay=0.006, lp_hz=3500, mix=0.16, harsh_cut=-5.0,
                  width_band=(800, 5000))


def wobble_plate(n, t, seed, count, lo, hi, base_decay, rate=22, depth=0.02):
    """短く揺れる金属の鳴り：周波数をわずかに揺らした非整数倍音。"""
    rng = np.random.default_rng(seed)
    y = np.zeros(n)
    for f in np.sort(rng.uniform(lo, hi, count)):
        dec = base_decay * (lo / f) ** 0.5 * rng.uniform(0.7, 1.3)
        ph = 2 * np.pi * f * t + (depth * f / rate) * np.sin(2 * np.pi * rate * t) + rng.uniform(0, 6.28)
        y += (lo / f) ** 0.6 * np.sin(ph) * np.exp(-t / dec)
    return y * -np.expm1(-t / 0.0004) / max(np.abs(y).max(), 1e-9)


def f03_heavy_actuator(dur=0.50):
    """F-03 ヘビー・アクチュエータ「ドバシュッ」：巨大な機構が押し出す重く締まった砲撃。高域は抑え、残響は短い。"""
    n = int(dur * SR); t = np.arange(n) / SR
    crack = sat(noise(n, 601, 1200, 6000) * env(t, 0.0003, 0.0055, 1.0) * 0.5, 2.5)
    boom = sat(np.sin(sweep_phase(t, 140, 46, 0.012)) * env(t, 0.0008, 0.085, 1.25), 2.2)
    punch = sat(noise(n, 602, 150, 1500) * env(t, 0.0004, 0.055, 1.2) * 0.5, 2.8)
    metal = wobble_plate(n, t, 603, 14, 400, 3200, 0.045)
    air = lp(noise(n, 604), 1800) * env(t, 0.001, 0.070, 1.1)
    mono = 0.85 * crack + 0.95 * boom + 0.90 * punch + 0.45 * metal + 0.25 * air
    return finish(mono, t, 605, rt60=0.32, predelay=0.008, lp_hz=3000, mix=0.14, harsh_cut=-4.0,
                  width_band=(600, 4000))


def f04_compact_beam(dur=0.35):
    """F-04 コンパクト・ビーム「シュヴィッ」：光線の素早い抜け。中域に芯を置き、長い「ピューン」は付けない。"""
    n = int(dur * SR); t = np.arange(n) / SR
    crack = sat(noise(n, 701, 2000, 11000) * env(t, 0.0001, 0.003, 1.0) * 0.45, 3)
    # 高速な周波数変化：2.6kHz→1.05kHz を約6msで駆け下りる芯。ノイズで変調して音程感を崩す
    ph = sweep_phase(t, 2600, 1050, 0.006)
    core = np.sin(ph) + 0.5 * np.sin(2 * ph + 0.3)
    core *= 0.65 + 0.35 * np.clip(noise(n, 702, 300, 3000) / 2.5, -1, 1)
    core = bp(core, 700, 4500) * env(t, 0.0003, 0.050, 1.25)
    core /= max(np.abs(core).max(), 1e-9)
    swish = resonant_lp_sweep(noise(n, 703), 6000, 1400, 0.008, 2.5)
    swish = swish / max(rms(swish[:int(0.02 * SR)]), 1e-9) * env(t, 0.0003, 0.055, 1.2) * 0.4
    spark = crackle(n, t, 704, 3000, 0.030, 3000, 9000)
    thump = sat(np.sin(sweep_phase(t, 170, 80, 0.006)) * env(t, 0.0006, 0.045, 1.3), 2.0)
    mono = 0.40 * crack + 0.55 * core + 0.60 * swish + 0.20 * spark + 0.50 * thump
    return finish(mono, t, 705, rt60=0.25, predelay=0.005, lp_hz=5000, mix=0.12, harsh_cut=-4.0)


def time_to(x, db):
    e = np.sqrt(np.convolve((x ** 2).mean(1), np.ones(480) / 480, 'same'))[::48]
    d = 20 * np.log10(e / e.max() + 1e-9)
    pk = int(np.argmax(e))
    return (pk + int(np.argmax(d[pk:] < db))) / 1000


def centroid(x):
    m = x.mean(1)
    F = np.abs(np.fft.rfft(m, 65536))
    f = np.fft.rfftfreq(65536, 1 / SR)
    return float((F * f).sum() / F.sum())


def main():
    out = Path(sys.argv[1]); bgm_path = sys.argv[2]; ref_path = sys.argv[3]
    (out / 'one_shots').mkdir(parents=True, exist_ok=True)
    ref, _ = sf.read(ref_path, dtype='float32')
    target = loud_db(ref)
    sounds = {
        'F-01_Sharp_Pulse_S3L': s3_plasma_blaster(1.5),
        'F-02_Dark_Pulse': f02_dark_pulse(),
        'F-03_Heavy_Actuator': f03_heavy_actuator(),
        'F-04_Compact_Beam': f04_compact_beam(),
    }
    print('name,main_part_to_-20dB_s,len_to_-40dB_s,peak,loud_vs_target_dB,centroid_Hz,'
          'below250Hz_share_dB,3-5kHz_share_dB,6-14kHz_share_dB,re_rise_dB')
    for k, w in sounds.items():
        w = w * 10 ** ((target - loud_db(w)) / 20)
        if np.abs(w).max() > 0.95:
            w *= 0.95 / np.abs(w).max()
        sounds[k] = w
        write(out / 'one_shots' / f'{k}.wav', w)
        print(k, time_to(w, -20), round(length_to(w), 3), round(float(np.abs(w).max()), 3),
              round(loud_db(w) - target, 1), round(centroid(w)), round(band_share(w, 90, 250), 1),
              round(band_share(w, 3000, 5000), 1), round(band_share(w, 6000, 14000), 1), round(re_rise(w), 1),
              sep=',')

    bgm, _ = sf.read(bgm_path, dtype='float32')
    seg0 = bgm[int(55.0 * SR):int(61.7 * SR)]
    seg0 = seg0 * min(1, 0.42 / max(0.01, np.abs(seg0).max()))
    gain = 0.65 * 10 ** (LEVEL_DB / 20)
    gap = np.zeros((int(0.45 * SR), 2), dtype=np.float32)
    chunks = []
    for w in sounds.values():
        v = seg0.copy()
        for s in (1.05, 2.75, 4.45):
            overlay(v, w * gain, s)
        if np.abs(v).max() > 0.95:
            v *= 0.95 / np.abs(v).max()
        chunks += [v, gap]
    wav = out / '_tmp_01.wav'
    write(wav, np.concatenate(chunks))
    subprocess.run(['afconvert', '-f', 'm4af', '-d', 'aac', '-b', '192000', str(wav),
                    str(out / '01_比較_BGM_A_55秒区間.m4a')], check=True)
    wav.unlink()


if __name__ == '__main__':
    main()
