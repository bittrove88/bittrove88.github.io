"""ARCLINE 効果音 再制作計画 v1.0 Gate 1：P0 の3本（_r1）とA/B比較。

P0-1 F-01_power_strong_r1：軽発射と同じ銃の音のまま、硬い芯と 200Hz〜4kHz の厚み・輪郭で強さを出す。
P0-2 I-04_Fracture_Hit_r1：低音の塊ではなく、乾いた破断と不規則な亀裂の連なりで「割れる」を出す。
P0-3 S-05_Core_Compression_r1：S-04 の終わり（約300Hz）を引き継ぐ凝縮した芯と、200Hz〜2kHz の衝撃で解放する。
旧版は上書きしない。新しい書き出しはピーク −3dBFS 以下を目標にする。
使い方: python gate1_p0_rework.py <出力先> <BGM A の wav> <ラウドネス基準の wav> <FINAL の sounds フォルダ>
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402
import soundfile as sf  # noqa: E402
from scipy.signal import butter, sosfilt, fftconvolve  # noqa: E402
from arcline_sfx_lib import (SR, LEVEL_DB, env, sweep_phase, bp, noise, sat, crush, crackle, metal_plate,  # noqa: E402
                             resonant_lp_sweep, finish, loud_db, write, overlay, time_to, re_rise20,
                             centroid, match_loudness, bgm_section, encode_m4a)
from phaseB_impacts import grains  # noqa: E402
from phaseC_ricochet_debris import debris  # noqa: E402
from phaseD_specials import f01v, s04_gravity_pull  # noqa: E402

PEAK_TARGET_DB = -3.0  # 新規書き出しのヘッドルーム（暫定）


def f01_power_strong_r1():
    """P0-1 強発射「バシュンッ」：軽発射と共通の破裂音・噴射を土台に、硬い機構の芯と砲身の厚みを同じ瞬間に重ねる。"""
    k = 1.35  # 旧版は 1.6。主要部分を 0.12〜0.25 秒に収める
    n = int(0.55 * SR); t = np.arange(n) / SR
    # 軽発射（seed 301〜303）と同じノイズを使い、同じ銃の音であることを保つ
    crack = sat(noise(n, 301, 1800, 12000) * env(t, 0.0001, 0.0040, 1.0) * 0.5, 3)
    plasma = resonant_lp_sweep(noise(n, 302), 7000, 800, 0.020 * k, 3.5)
    plasma = sat(plasma / max(np.sqrt(np.mean(plasma[:int(0.03 * SR)] ** 2)), 1e-9) *
                 env(t, 0.0003, 0.045 * k, 1.2) * 0.4, 2.0)
    sizzle = bp(crush(noise(n, 303) * 0.3, 4, 6), 2000, 8000) * env(t, 0.0005, 0.050 * k, 1.1)
    sizzle /= max(np.sqrt(np.mean(sizzle[:int(0.04 * SR)] ** 2)), 1e-9)
    # 強く押し出す硬い芯：金属機構の短い鳴り（1.1〜4kHz）を破裂音と同時に立ち上げる
    clank = metal_plate(n, t, 311, 10, 1100, 4000, 0.012)
    # 砲身の厚み（200〜800Hz）：飽和させた帯域ノイズと、倍音の多い短い胴鳴り
    barrel = sat(noise(n, 312, 200, 800) * env(t, 0.0004, 0.060, 1.2) * 0.5, 2.6)
    body = sat(np.sin(sweep_phase(t, 230, 140, 0.006)) * env(t, 0.0004, 0.065, 1.3), 3.0)
    # 射出の輪郭（800Hz〜4kHz）
    contour = sat(noise(n, 313, 800, 4000) * env(t, 0.0002, 0.030, 1.2) * 0.5, 2.2)
    # 超低域は補助にとどめる
    sub = np.sin(sweep_phase(t, 110, 62, 0.010)) * env(t, 0.0006, 0.045, 1.3)
    mono = (0.70 * crack + 0.80 * plasma + 0.16 * sizzle + 0.24 * clank + 0.65 * barrel + 0.55 * body +
            0.45 * contour + 0.55 * sub)
    return finish(mono, t, 315, rt60=0.30, predelay=0.005, lp_hz=5500, mix=0.14, harsh_cut=-5.0)


def hard_modes_ir(freqs, decays, dur=0.03):
    t = np.arange(int(dur * SR)) / SR
    ir = sum(np.sin(2 * np.pi * f * t + i) * np.exp(-t / d) for i, (f, d) in enumerate(zip(freqs, decays)))
    return ir / np.abs(ir).max()


def i04_fracture_hit_r1(dur=0.45):
    """P0-2 破砕衝撃「バキッ、ガシャッ」：乾いた破断の一撃に、最初の 30ms へ密集する微小な亀裂と裂ける質感を重ねる。"""
    n = int(dur * SR); t = np.arange(n) / SR
    crack = sat(noise(n, 1701, 1500, 10000) * env(t, 0.0001, 0.0018, 1.0) * 0.5, 3.0)
    # 不規則な亀裂の連なり：密度が急に減る微小な破断を、硬い材質の短い共鳴に通す
    micro = crackle(n, t, 1702, 18000, 0.024, 1200, 6500)
    micro = fftconvolve(micro, hard_modes_ir((1300, 2100, 2900, 3700), (0.008, 0.006, 0.005, 0.004)))[:n]
    micro /= max(np.abs(micro).max(), 1e-9)
    # 裂ける金属・硬質材のザラつき：歪ませた中高域ノイズを不規則な粒で刻む
    rasp = sat(noise(n, 1703, 1200, 5500) * env(t, 0.0003, 0.090, 1.15) * 0.5, 3.2)
    rasp = crush(rasp * 0.8, 6, 2) * (0.35 + 0.65 * grains(n, t, 1704, 1400, 0.040, 300, 8000, grain_ms=(1, 3)))
    rasp = bp(rasp, 900, 5000)
    rasp /= max(np.abs(rasp).max(), 1e-9)
    # 低い衝撃は 150〜400Hz に置く（超低域は使わない）
    knock = sat(np.sin(sweep_phase(t, 330, 180, 0.005)) * env(t, 0.0003, 0.050, 1.3), 2.5)
    thud = sat(noise(n, 1705, 150, 600) * env(t, 0.0003, 0.050, 1.2) * 0.45, 2.4)
    low = sat(np.sin(sweep_phase(t, 140, 95, 0.006)) * env(t, 0.0004, 0.040, 1.3), 2.0)
    # 破断直後に残る小さく短い硬質の欠片（数個だけ。長い破片の音は D-01 の役割）
    bits = debris(n, t, 1706, 0.030, 0.22, 55, 0.07)
    mono = 0.45 * crack + 0.60 * micro + 0.60 * rasp + 0.55 * knock + 0.50 * thud + 0.25 * low + 0.12 * bits
    return finish(mono, t, 1707, rt60=0.26, predelay=0.004, lp_hz=5000, mix=0.12, harsh_cut=-5.5)


def s05_core_compression_r1(dur=0.50):
    """P0-3 圧縮解放「ドシュンッ」：S-04 の終わりの約300Hzを引き継ぐ凝縮した芯から、200Hz〜2kHz の衝撃で一気に解放する。"""
    n = int(dur * SR); t = np.arange(n) / SR
    pc = 2 * np.pi * 300 * t
    kernel = np.sin(pc + (1.5 + 6.0 * np.exp(-t / 0.008)) * np.sin(1.5 * pc)) * env(t, 0.0002, 0.030, 1.2)
    crack = sat(noise(n, 1801, 1200, 8000) * env(t, 0.0001, 0.0025, 1.0) * 0.5, 3.0)
    burst = sat(noise(n, 1802, 200, 2000) * env(t, 0.0003, 0.070, 1.2) * 0.5, 3.0)
    # 低い圧力の波：下降させない短い低音。飽和させた倍音で 200Hz 以上にも届かせる
    press = sat(np.sin(2 * np.pi * 95 * t) * env(t, 0.0008, 0.085, 1.3), 2.2)
    # 短いエネルギーの歪み
    buzz = bp(crush(np.sin(0.5 * pc + 4.0 * np.sin(0.75 * pc)) * 0.6, 5, 3), 300, 3000) * env(t, 0.0003, 0.050, 1.2)
    mono = 0.35 * crack + 0.60 * kernel + 0.80 * burst + 0.65 * press + 0.25 * buzz
    return finish(mono, t, 1805, rt60=0.28, predelay=0.005, lp_hz=4000, mix=0.12, harsh_cut=-5.0)


# ---- 計測 ----

def share_below(x, f0):
    m = x.mean(1); F = np.abs(np.fft.rfft(m)) ** 2; f = np.fft.rfftfreq(len(m), 1 / SR)
    return float(F[f < f0].sum() / F.sum())


def share_band(x, lo, hi):
    m = x.mean(1); F = np.abs(np.fft.rfft(m)) ** 2; f = np.fft.rfftfreq(len(m), 1 / SR)
    return float(F[(f >= lo) & (f < hi)].sum() / F.sum())


def highpass(x, f, order=4):
    return sosfilt(butter(order, f, 'highpass', fs=SR, output='sos'), x, axis=0)


def rms_db(x):
    return 20 * np.log10(np.sqrt(np.mean(x ** 2)) + 1e-12)


def peak_db(x):
    return 20 * np.log10(np.abs(x).max() + 1e-12)


def row(name, w, target):
    lc = loud_db(highpass(w, 200)) - loud_db(w)
    return [name, time_to(w, -20), round(len(w) / SR, 3), round(peak_db(w), 1), round(loud_db(w) - target, 1),
            round(100 * share_below(w, 100)), round(100 * share_band(w, 200, 2000)), round(100 * share_band(w, 800, 4000)),
            round(lc, 1), round(centroid(w)), round(re_rise20(w), 1)]


def export(w, target, offset):
    """旧版と同じ役割の音量（ラウドネス）を求め、ピークが −3dBFS を超える分だけファイル全体を下げて書き出す。
    音色は変えない。戻り値は（書き出す音源, 旧版と同じ大きさで鳴らすための再生補正 dB）。"""
    w = match_loudness(w, target, offset, ceiling=99)
    ceiling = 10 ** (PEAK_TARGET_DB / 20)
    pk = np.abs(w).max()
    if pk <= ceiling:
        return w, 0.0
    return w * ceiling / pk, 20 * np.log10(pk / ceiling)


def main():
    out = Path(sys.argv[1]); bgm_path = sys.argv[2]; ref_path = sys.argv[3]; final = Path(sys.argv[4])
    (out / 'sounds').mkdir(parents=True, exist_ok=True)
    ref, _ = sf.read(ref_path, dtype='float64')
    target = loud_db(ref)
    old = {k: sf.read(final / p, dtype='float64')[0] for k, p in {
        'light': 'F_fire/F-01_power_light.wav', 'strong': 'F_fire/F-01_power_strong.wav',
        'f01': 'F_fire/F-01_Sharp_Pulse_S3L.wav', 'i02': 'I_impact/I-02_Armor_Slam.wav',
        'i04': 'I_impact/I-04_Fracture_Hit.wav', 'i05': 'I_impact/I-05_Pressure_Impact.wav',
        'd01': 'D_debris/D-01_Debris_Break.wav', 's04': 'S_special/S-04_Gravity_Pull.wav',
        's05': 'S_special/S-05_Core_Compression.wav', 'yui': 'SP_fire/SP_fire_yui.wav'}.items()}
    # 旧版と同じ役割の音量差（旧版の実測値）で書き出す
    offs = {k: loud_db(old[k]) - target for k in ('strong', 'i04', 's05')}
    new, comp, play = {}, {}, {}
    for k, fn in (('strong', f01_power_strong_r1), ('i04', i04_fracture_hit_r1), ('s05', s05_core_compression_r1)):
        new[k], comp[k] = export(fn(), target, offs[k])
        play[k] = new[k] * 10 ** (comp[k] / 20)  # 試聴は旧版と同じ大きさで鳴らす
        print(f'{k}: 役割の音量 {offs[k]:+.1f}dB、書き出しピーク {20 * np.log10(np.abs(new[k]).max()):.1f}dBFS、'
              f'再生補正 {comp[k]:+.1f}dB')
    names = {'strong': 'F-01_power_strong_r1', 'i04': 'I-04_Fracture_Hit_r1', 's05': 'S-05_Core_Compression_r1'}
    for k, w in new.items():
        write(out / 'sounds' / f'{names[k]}.wav', w)

    cols = ['name', 'main_-20dB_s', 'file_s', 'peak_dBFS', 'loud_vs_ref_dB', 'below100Hz_%', '200-2kHz_%',
            '800-4kHz_%', 'loud_change_after_HPF200_dB', 'centroid_Hz', 're_rise20_dB']
    print(','.join(cols))
    for name, w in [('light(旧)', old['light']), ('strong(旧)', old['strong']), ('strong_r1(補正後)', play['strong']),
                    ('I-02(旧)', old['i02']), ('I-04(旧)', old['i04']), ('I-04_r1(補正後)', play['i04']), ('I-05(旧)', old['i05']),
                    ('S-05(旧)', old['s05']), ('S-05_r1(補正後)', play['s05'])]:
        print(','.join(map(str, row(name, w, target))))
    L = old['light']
    for name, S in [('strong(旧)', old['strong']), ('strong_r1', play['strong'])]:
        print(f'{name} − light: 全帯域RMS差 {rms_db(S) - rms_db(L):+.1f}dB, 250Hz以上RMS差 '
              f'{rms_db(highpass(S, 250)) - rms_db(highpass(L, 250)):+.1f}dB, '
              f'同ラウドネス時の200Hz以上の差 {loud_db(highpass(match_loudness(S, loud_db(L) - 0, 0, 9), 200)) - loud_db(highpass(L, 200)):+.1f}dB')
    a, b = L[:int(0.22 * SR)].mean(1), play['strong'][:int(0.22 * SR)].mean(1)
    print('冒頭220ms相関 light vs strong_r1: %.3f' % (np.dot(a, b) / np.linalg.norm(a) / np.linalg.norm(b)))

    # ---- A/B 比較（同じBGM区間・同じ時刻・同じ音量） ----
    bgm, _ = sf.read(bgm_path, dtype='float64')
    seg0 = bgm_section(bgm)
    G = 0.65 * 10 ** (LEVEL_DB / 20)
    d = lambda v: 10 ** (v / 20)  # noqa: E731

    def scene(events):
        v = seg0.copy()
        for at, w, g in events:
            overlay(v, w * G * g, at)
        return v

    # P0-1 は軽発射と同じラウドネスに揃えて比べる（強さが音量差だけでないかを確かめる）
    eq = lambda w: match_loudness(w, loud_db(old['light']), 0, 9)  # noqa: E731
    lt = old['light']
    f01 = old['f01']
    scenes = [
        ('P0-1 旧', scene([(1.00, lt, 1), (2.30, eq(old['strong']), 1), (3.60, lt, 1), (4.90, eq(old['strong']), 1)])),
        ('P0-1 新', scene([(1.00, lt, 1), (2.30, eq(new['strong']), 1), (3.60, lt, 1), (4.90, eq(new['strong']), 1)])),
        ('P0-2 旧', scene([(0.90, f01, 1), (1.70, old['i02'], 1), (2.60, f01, 1), (3.40, old['i04'], 1),
                          (4.30, f01, 1), (5.10, old['i05'], 1)])),
        ('P0-2 新', scene([(0.90, f01, 1), (1.70, old['i02'], 1), (2.60, f01, 1), (3.40, play['i04'], 1),
                          (4.30, f01, 1), (5.10, old['i05'], 1)])),
        ('P0-2 D-01', scene([(0.90, f01, 1), (1.70, old['i04'], 1), (1.715, old['d01'], d(-3)),
                            (3.20, f01, 1), (4.00, play['i04'], 1), (4.015, old['d01'], d(-3))])),
        ('P0-3 旧', scene([(0.70, old['yui'], 1), (1.40, old['i05'], d(-4)), (1.40, old['s04'], 1), (2.00, old['s05'], 1),
                          (3.60, old['yui'], 1), (4.30, old['i05'], d(-4)), (4.30, old['s04'], 1), (4.90, old['s05'], 1)])),
        ('P0-3 新', scene([(0.70, old['yui'], 1), (1.40, old['i05'], d(-4)), (1.40, old['s04'], 1), (2.00, play['s05'], 1),
                          (3.60, old['yui'], 1), (4.30, old['i05'], d(-4)), (4.30, old['s04'], 1), (4.90, play['s05'], 1)])),
    ]
    gap = np.zeros((int(0.45 * SR), 2))
    chunks, pos = [], 0.0
    for label, v in scenes:
        pk = float(np.abs(v).max())
        print(f'scene {label}: start {pos:5.2f}s peak {pk:.3f}' + ('  -> normalized' if pk > 0.95 else ''))
        if pk > 0.95:
            v = v * 0.95 / pk
        chunks += [v, gap]
        pos += (len(v) + len(gap)) / SR
    mix = np.concatenate(chunks)
    encode_m4a(mix, out / '01_AB比較_BGM_A_55秒区間.m4a', out)
    # 低域の乏しい再生環境の想定：全体に 200Hz 以下を切るフィルター（24dB/oct）をかけ、全体のラウドネスだけ元に戻す
    lc = highpass(mix, 200)
    lc *= 10 ** ((loud_db(mix) - loud_db(lc)) / 20)
    if np.abs(lc).max() > 0.95:
        lc *= 0.95 / np.abs(lc).max()
    encode_m4a(lc, out / '02_AB比較_BGM_A_55秒区間_低域カット200Hz.m4a', out)


if __name__ == '__main__':
    main()
