"""効果音の台帳（再制作計画 v1.0 §9）を作る：ファイルごとの SHA-256・尺・ピーク・版・計画上の優先度・使うイベント。
使い方: python gate1_ledger.py <download_o フォルダ> <出力 CSV>
"""
import csv
import hashlib
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402
import soundfile as sf  # noqa: E402
from arcline_sfx_lib import SR, time_to  # noqa: E402

# ファイル名 → (ID, 使うイベント・用途, 計画書の区分, 備考)
INFO = {
    'F-01_Sharp_Pulse_S3L': ('F-01', '自機の通常発射（FIRE威力：中）', 'P3 維持', ''),
    'F-01_power_light': ('F-01', '自機の通常発射（FIRE威力：軽）', 'P3 維持', ''),
    'F-01_power_strong': ('F-01', '自機の通常発射（FIRE威力：強）', 'P0 再制作', '改修案 F-01_power_strong_r1 あり'),
    'F-02_Dark_Pulse': ('F-02', '敵の通常発射', 'P3 維持', ''),
    'F-03_Heavy_Actuator': ('F-03', '敵の重量発射', 'P3 維持', ''),
    'F-04_Compact_Beam': ('F-04', '敵のエネルギー発射', 'P3 維持', '敵の攻撃分類がエネルギー系の場合のみ'),
    'I-01_Hard_Contact': ('I-01', 'impact（通常弾・軽量弾・敵の通常弾・ハナ・ソラの子弾）', 'P3 維持', ''),
    'I-02_Armor_Slam': ('I-02', 'impact（ガン・コロの最終爆発・敵の重量弾）', 'P2 比較で判断', ''),
    'I-03_Plasma_Snap': ('I-03', 'impact（リン・敵のエネルギー攻撃）', 'P3 維持', ''),
    'I-03_airburst_variant_hibari': ('I-03', 'airburst（ヒバリの近接起爆）', 'P3 維持', ''),
    'I-04_Fracture_Hit': ('I-04', 'impact／breach-pulse（モグ・破砕系の攻撃）', 'P0 再制作', '改修案 I-04_Fracture_Hit_r1 あり'),
    'I-05_Pressure_Impact': ('I-05', 'impact（バン・ユイの接触）', 'P2 比較で判断', ''),
    'R-01_Ricochet_v1': ('R-01', 'bounce（全武器の通常の跳弾）', 'P3 維持（計画書では試作保管）', '要確認：設計資料v3では全武器の通常跳弾用'),
    'R-01_Ricochet_v2': ('R-01', 'bounce（全武器の通常の跳弾）', 'P3 維持（計画書では試作保管）', '要確認：設計資料v3では全武器の通常跳弾用'),
    'R-01_Ricochet_v3': ('R-01', 'bounce（全武器の通常の跳弾）', 'P3 維持（計画書では試作保管）', '要確認：設計資料v3では全武器の通常跳弾用'),
    'R-01_Rico_bounce1': ('R-01', 'bounce（リコ count=1）', 'P3 維持', ''),
    'R-01_Rico_bounce2': ('R-01', 'bounce（リコ count=2）', 'P3 維持', ''),
    'R-01_Rico_bounce3': ('R-01', 'bounce（リコ count=3）', 'P2 比較で判断', ''),
    'R-01_Rico_bounce4': ('R-01', 'bounce（リコ count=4）', 'P2 比較で判断', ''),
    'I-01_I-02_Rico_final_blend': ('I-01+I-02', 'impact（リコの最終着弾）', 'P2 比較で判断', ''),
    'D-01_Debris_Break': ('D-01', 'break（実際に壊れた時のみ）', 'P3 維持', ''),
    'S-01_Pressure_Wave': ('S-01', 'shockwave（バン）', 'P3 維持', ''),
    'S-02_Meteor_Split': ('S-02', 'split（ソラ、1回のみ）', 'P2 比較で判断', ''),
    'S-03_Rolling_Drive_1.2s': ('S-03', 'roll（コロ、転走中のみ。長さは状態で変える）', 'P3 維持', '1.2秒は例'),
    'S-03_Roll_Fall': ('S-03', 'roll-fall（コロ）', 'P3 維持', ''),
    'S-04_Gravity_Pull': ('S-04', 'pull（ユイ、0.6秒）', 'P3 維持', ''),
    'S-05_Core_Compression': ('S-05', 'compression（ユイ）', 'P0 再制作', '改修案 S-05_Core_Compression_r1 あり'),
    'S-06_Pinpoint_Break': ('S-06', 'critical（リン）', 'P2 比較で判断', ''),
    'SP_fire_gun': ('F-01 変奏', '必殺技の発射（ガン）', 'P1 Gate 2 で改修', ''),
    'SP_fire_ban': ('F-01 変奏', '必殺技の発射（バン）', 'P1 Gate 2 で改修', ''),
    'SP_fire_hibari': ('F-01 変奏', '必殺技の発射（ヒバリ）', 'P3 維持（P2 で比較）', 'リコと比較'),
    'SP_fire_hana_1': ('F-01 変奏', '必殺技の発射（ハナ 1発目）', 'P3 維持（P2 で比較）', 'ユイと比較'),
    'SP_fire_hana_2': ('F-01 変奏', '必殺技の発射（ハナ 2発目）', 'P3 維持', ''),
    'SP_fire_hana_3': ('F-01 変奏', '必殺技の発射（ハナ 3発目）', 'P3 維持', ''),
    'SP_fire_rin': ('F-01 変奏', '必殺技の発射（リン）', 'P3 維持', ''),
    'SP_fire_mogu': ('F-01 変奏', '必殺技の発射（モグ）', 'P1 Gate 2 で改修', ''),
    'SP_fire_koro': ('F-01 変奏', '必殺技の発射（コロ）', 'P1 Gate 2 で改修', ''),
    'SP_fire_sora': ('F-01 変奏', '必殺技の発射（ソラ）', 'P3 維持', ''),
    'SP_fire_rico': ('F-01 変奏', '必殺技の発射（リコ）', 'P3 維持（P2 で比較）', 'ヒバリと比較'),
    'SP_fire_yui': ('F-01 変奏', '必殺技の発射（ユイ）', 'P3 維持（P2 で比較）', 'ハナ1発目と比較'),
}
R1 = {  # 改修案：元のファイル名 → 再生補正 dB（旧版と同じ大きさで鳴らすための値）
    'F-01_power_strong': 4.1, 'I-04_Fracture_Hit': 1.7, 'S-05_Core_Compression': 0.2,
}


def describe(p, base):
    w, sr = sf.read(p, dtype='float64')
    assert sr == SR
    m = w.mean(1)
    F = np.abs(np.fft.rfft(m)) ** 2
    f = np.fft.rfftfreq(len(m), 1 / SR)
    return {
        '場所': str(p.relative_to(base)),
        '尺_秒': f'{len(w) / SR:.3f}',
        '主要部分_秒（-20dBまで）': f'{time_to(w, -20):.3f}',
        'ピーク_dBFS': f'{20 * np.log10(np.abs(w).max()):.1f}',
        '100Hz未満のエネルギー_%': f'{100 * F[f < 100].sum() / F.sum():.0f}',
        'SHA-256': hashlib.sha256(p.read_bytes()).hexdigest(),
    }


def main():
    base = Path(sys.argv[1]); out = Path(sys.argv[2])
    rows = []
    for p in sorted((base / 'ARCLINE_SFX_FINAL' / 'sounds').glob('*/*.wav')):
        name = p.stem
        sid, ev, pri, note = INFO[name]
        rows.append({'ファイル': p.name, 'ID': sid, '版': 'r0', '使うイベント・用途': ev, '計画書の区分': pri,
                     '状態': '現行（未実装）', '再生補正_dB': '0.0', **describe(p, base), '備考': note})
    for p in sorted((base / 'ARCLINE_SFX_rework_gate1' / 'sounds').glob('*_r1.wav')):
        orig = p.stem[:-3]
        sid, ev, pri, _ = INFO[orig]
        rows.append({'ファイル': p.name, 'ID': sid, '版': 'r1', '使うイベント・用途': ev, '計画書の区分': pri,
                     '状態': '改修案（Gate 1 審査中）', '再生補正_dB': f'{R1[orig]:+.1f}', **describe(p, base),
                     '備考': f'{orig}.wav の改修案。ピーク -3dBFS で書き出し'})
    cols = ['ファイル', 'ID', '版', '状態', '計画書の区分', '使うイベント・用途', '尺_秒', '主要部分_秒（-20dBまで）',
            'ピーク_dBFS', '再生補正_dB', '100Hz未満のエネルギー_%', '場所', 'SHA-256', '備考']
    with open(out, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)
    print(len(rows), 'rows')


if __name__ == '__main__':
    main()
