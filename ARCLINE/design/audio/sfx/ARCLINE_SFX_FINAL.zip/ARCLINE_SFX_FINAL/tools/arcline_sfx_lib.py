"""ARCLINE 効果音 共通ライブラリ（合成部品・計測・BGM 重ね合わせ）。

F-01（自機の基本発射）は S3L＝s3_plasma_blaster(1.5) で確定。以下は第5試作スクリプトからの流用。

音程のある「ピュン」を主役にせず、破裂音・低域の衝撃・中域の破裂ノイズ・電気的な質感・短い残響を
同時に重ねて一発の銃声として作る。全レイヤーが同時に立ち上がる「一発＝一音」。
使い方: python create_arcline_shot_round4.py <出力先> <BGM A の wav> <ラウドネス基準の wav>
"""
import subprocess
import sys
from pathlib import Path
import numpy as np
import soundfile as sf
from scipy.signal import butter, sosfilt, lfilter, fftconvolve

SR = 48000
LEVEL_DB = -4.0  # 確定した音量：前回試聴（0.65倍）から −4dB


def rms(x):
    return float(np.sqrt(np.mean(np.square(x)) + 1e-12))


def env(t, attack, decay, power=1.2):
    return -np.expm1(-t / attack) * np.exp(-(t / decay) ** power)


def sweep_phase(t, f0, f1, tau):
    return 2 * np.pi * (f1 * t + (f0 - f1) * tau * (1 - np.exp(-t / tau)))


def bp(x, lo, hi, order=2):
    return sosfilt(butter(order, (lo, hi), 'bandpass', fs=SR, output='sos'), x, axis=0)


def hp(x, f, order=2):
    return sosfilt(butter(order, f, 'highpass', fs=SR, output='sos'), x, axis=0)


def lp(x, f, order=2):
    return sosfilt(butter(order, f, 'lowpass', fs=SR, output='sos'), x, axis=0)


def noise(n, seed, lo=None, hi=None):
    z = np.random.default_rng(seed).standard_normal(n)
    if lo and hi:
        z = bp(z, lo, hi, 3)
    elif lo:
        z = hp(z, lo, 3)
    elif hi:
        z = lp(z, hi, 3)
    return z / max(rms(z), 1e-9)


def sat(x, drive):
    return np.tanh(drive * x) / np.tanh(drive)


def crush(x, bits, hold):
    """ビット深度と標本化を粗くして、デジタルな電気の質感を付ける。"""
    y = np.repeat(x[::hold], hold)[:len(x)]
    q = 2 ** (bits - 1)
    return np.round(y * q) / q


def peaking(x, f0, gain_db, q):
    a = 10 ** (gain_db / 40)
    w = 2 * np.pi * f0 / SR
    al = np.sin(w) / (2 * q)
    b = [1 + al * a, -2 * np.cos(w), 1 - al * a]
    d = [1 + al / a, -2 * np.cos(w), 1 - al / a]
    return lfilter(np.array(b) / d[0], np.array(d) / d[0], x, axis=0)


def crackle(n, t, seed, rate, tau, lo, hi):
    """放電のパチパチ音：密度が減衰していく疎なインパルス列。"""
    rng = np.random.default_rng(seed)
    prob = rate / SR * np.exp(-t / tau)
    imp = (rng.random(n) < prob) * rng.uniform(0.3, 1.0, n) * rng.choice([-1, 1], n)
    y = bp(imp, lo, hi, 2)
    return y / max(np.abs(y).max(), 1e-9)


def metal_plate(n, t, seed, count, lo, hi, base_decay):
    """叩いた金属板のような高密度の非整数倍音（音程感を出さない）。"""
    rng = np.random.default_rng(seed)
    y = np.zeros(n)
    for f in np.sort(rng.uniform(lo, hi, count)):
        dec = base_decay * (lo / f) ** 0.6 * rng.uniform(0.7, 1.3)
        y += (lo / f) ** 0.7 * np.sin(2 * np.pi * f * t + rng.uniform(0, 6.28)) * np.exp(-t / dec)
    return y * -np.expm1(-t / 0.0003) / max(np.abs(y).max(), 1e-9)


def resonant_lp_sweep(x, f_start, f_end, tau, q):
    """カットオフが急降下する共鳴ローパス（ノイズに通して音程感の薄いエネルギー感を作る）。"""
    out = np.zeros_like(x)
    z1 = z2 = 0.0
    blk = 64
    for s in range(0, len(x), blk):
        fc = f_end + (f_start - f_end) * np.exp(-(s / SR) / tau)
        w = 2 * np.pi * fc / SR
        al = np.sin(w) / (2 * q)
        cw = np.cos(w)
        a0 = 1 + al
        b = np.array([(1 - cw) / 2, 1 - cw, (1 - cw) / 2]) / a0
        a = np.array([1, -2 * cw / a0, (1 - al) / a0])
        seg, zf = lfilter(b, a, x[s:s + blk], zi=np.array([z1, z2]))
        out[s:s + blk] = seg
        z1, z2 = zf
    return out


def compress(x, thr_db=-14, ratio=4.0, att=0.0008, rel=0.045):
    """簡易コンプレッサー（立ち上がりを潰しすぎない速めの設定）。"""
    lvl = np.abs(x).max(axis=1) if x.ndim == 2 else np.abs(x)
    ga, gr = np.exp(-1 / (att * SR)), np.exp(-1 / (rel * SR))
    e = 0.0
    g = np.ones(len(lvl))
    thr = 10 ** (thr_db / 20)
    for i, v in enumerate(lvl):
        e = ga * e + (1 - ga) * v if v > e else gr * e + (1 - gr) * v
        if e > thr:
            g[i] = (thr * (e / thr) ** (1 / ratio)) / e
    return x * (g[:, None] if x.ndim == 2 else g)


def reverb(mono, seed, rt60, predelay, lp_hz, mix):
    """短い空間残響：減衰ノイズのインパルス応答（左右で無相関）を畳み込む。"""
    n = int(rt60 * 1.2 * SR)
    t = np.arange(n) / SR
    rng = np.random.default_rng(seed)
    decay = np.exp(-6.91 * t / rt60)
    ir = rng.standard_normal((n, 2)) * decay[:, None]
    ir = lp(hp(ir, 220), lp_hz)
    ir[:int(predelay * SR)] = 0
    ir /= np.sqrt(np.sum(ir ** 2, axis=0))
    wet = np.column_stack([fftconvolve(mono, ir[:, c])[:len(mono)] for c in range(2)])
    return np.column_stack((mono, mono)) + mix * wet


def finish(mono, t, seed, rt60, predelay, lp_hz, mix, harsh_cut=-3.0, width=0.10, width_band=(1500, 9000)):
    mono = hp(mono, 45)
    mono = compress(mono)
    mono = sat(mono / max(np.abs(mono).max(), 1e-9) * 0.9, 1.6)
    mono = peaking(mono, 3800, harsh_cut, 1.0)
    st = reverb(mono, seed, rt60, predelay, lp_hz, mix)
    side = noise(len(t), seed + 50, *width_band) * env(t, 0.0003, 0.02) * width * np.abs(mono).max()
    st[:, 0] += side
    st[:, 1] -= side
    fade = int(0.04 * SR)
    st[-fade:] *= np.linspace(1, 0, fade)[:, None] ** 1.5
    st -= st.mean(axis=0)
    return st


def s1_pulse_rifle(dur=0.45):
    """S1 パルスライフル：SF の軍用エネルギー小銃。破裂音＋中域の破裂＋低域＋放電の質感。最も標準的。"""
    n = int(dur * SR); t = np.arange(n) / SR
    crack = sat(noise(n, 101, 1500, 12000) * env(t, 0.0001, 0.004, 1.0) * 0.5, 3)
    punch = sat(noise(n, 102, 250, 2500) * env(t, 0.0003, 0.032, 1.2) * 0.45, 2.5)
    thump = sat(np.sin(sweep_phase(t, 180, 55, 0.006)) * env(t, 0.0005, 0.060, 1.3), 2.0)
    carrier = np.sign(np.sin(sweep_phase(t, 1250, 760, 0.020))) + np.sign(np.sin(sweep_phase(t, 1262, 768, 0.020)))
    zap = crush(carrier * noise(n, 103, 800, 6000) * env(t, 0.0005, 0.028, 1.2) * 0.25, 6, 3)
    spark = crackle(n, t, 104, 2600, 0.035, 2500, 9000)
    mono = 0.95 * crack + 0.85 * punch + 0.85 * thump + 0.22 * zap + 0.28 * spark
    return finish(mono, t, 105, rt60=0.45, predelay=0.006, lp_hz=5000, mix=0.20)


def s2_rail_cannon(dur=0.60):
    """S2 レールキャノン：電磁投射砲。鋭い破裂と金属の鳴り、高電圧の放電、重い低域。最も重厚。"""
    n = int(dur * SR); t = np.arange(n) / SR
    crack = sat(noise(n, 201, 2000, 14000) * env(t, 0.0001, 0.003, 1.0) * 0.55, 3)
    metal = metal_plate(n, t, 202, 18, 900, 7000, 0.030)
    buzz = 1 + 0.6 * np.sign(np.sin(2 * np.pi * 100 * t))
    hiss = noise(n, 203, 3000, 10000) * buzz * env(t, 0.001, 0.080, 1.0) / 1.6
    boom = sat(np.sin(sweep_phase(t, 120, 42, 0.012)) * env(t, 0.001, 0.110, 1.2), 1.8)
    body = sat(noise(n, 204, 150, 1200) * env(t, 0.0004, 0.048, 1.2) * 0.45, 2.2)
    mono = 0.90 * crack + 0.30 * metal + 0.14 * hiss + 0.95 * boom + 0.75 * body
    return finish(mono, t, 205, rt60=0.70, predelay=0.010, lp_hz=4500, mix=0.26)


def s3_plasma_blaster(stretch=1.0):
    """S3 プラズマブラスター：ノイズを急降下する共鳴フィルターに通したエネルギー弾。音程感を抑えた噴射音。"""
    # stretch で余韻の長さを伸ばす。立ち上がりの破裂音（クラック）は伸ばさずキレを保つ
    k = stretch
    n = int((0.45 + 0.25 * (k - 1)) * SR); t = np.arange(n) / SR
    crack = sat(noise(n, 301, 1800, 12000) * env(t, 0.0001, 0.0035, 1.0) * 0.5, 3)
    plasma = resonant_lp_sweep(noise(n, 302), 7500, 700, 0.020 * k, 3.5)
    plasma = sat(plasma / max(rms(plasma[:int(0.03 * SR)]), 1e-9) * env(t, 0.0003, 0.045 * k, 1.2) * 0.4, 2.0)
    sizzle = bp(crush(noise(n, 303) * 0.3, 4, 6), 2000, 8000) * env(t, 0.0005, 0.050 * k, 1.1)
    sizzle /= max(rms(sizzle[:int(0.04 * SR)]), 1e-9)
    thump = sat(np.sin(sweep_phase(t, 150, 60, 0.008 * k)) * env(t, 0.0005, 0.050 * k, 1.3), 2.0)
    mono = 0.85 * crack + 0.80 * plasma + 0.14 * sizzle + 0.80 * thump
    return finish(mono, t, 305, rt60=0.40 * k, predelay=0.006, lp_hz=5500, mix=0.20, harsh_cut=-4.5)


def s4_striker(dur=0.32):
    """S4 ストライカー：本格 STG の自機弾のような、短く締まった重い連射向けの一撃。残響は最小限。"""
    n = int(dur * SR); t = np.arange(n) / SR
    crack = sat(noise(n, 401, 1500, 12000) * env(t, 0.0001, 0.003, 1.0) * 0.55, 3)
    sq = np.sign(np.sin(sweep_phase(t, 230, 105, 0.010)))
    crunch = crush(sat(sq * env(t, 0.0004, 0.040, 1.3) * 0.6, 3), 5, 2)
    punch = sat(noise(n, 402, 400, 3000) * env(t, 0.0003, 0.028, 1.2) * 0.5, 2.5)
    thump = sat(np.sin(sweep_phase(t, 200, 70, 0.005)) * env(t, 0.0005, 0.040, 1.3), 2.0)
    mono = 0.95 * crack + 0.20 * crunch + 0.85 * punch + 0.80 * thump
    return finish(mono, t, 405, rt60=0.22, predelay=0.004, lp_hz=6000, mix=0.14)


# ---- 計測 ----

def k_weight(x):
    b1 = [1.53512485958697, -2.69169618940638, 1.19839281085285]
    a1 = [1.0, -1.69065929318241, 0.73248077421585]
    b2 = [1.0, -2.0, 1.0]
    a2 = [1.0, -1.99004745483398, 0.99007225036621]
    return lfilter(b2, a2, lfilter(b1, a1, x, axis=0), axis=0)


def loud_db(x, win=0.1):
    p = np.sum(k_weight(x) ** 2, axis=1)
    w = int(win * SR)
    return -0.691 + 10 * np.log10(np.convolve(p, np.ones(w) / w, 'valid').max() + 1e-12)


def band_share(x, lo, hi):
    m = x.mean(1)
    F = np.abs(np.fft.rfft(m, 65536)) ** 2
    f = np.fft.rfftfreq(65536, 1 / SR)
    return 10 * np.log10(F[(f >= lo) & (f < hi)].sum() / F[f >= 90].sum())


def re_rise(x):
    e = np.sqrt(np.convolve((x ** 2).mean(1), np.ones(480) / 480, 'same'))[::48]
    db = 20 * np.log10(e / e.max() + 1e-9)
    seg = db[int(np.argmax(e)):]
    seg = seg[:int(np.argmax(seg < -20))]
    return float((seg - np.minimum.accumulate(seg)).max())


def length_to(x, db=-40):
    a = np.abs(x).max(1)
    return np.where(a > a.max() * 10 ** (db / 20))[0][-1] / SR


def write(path, a):
    sf.write(str(path), a.astype(np.float32), SR, subtype='PCM_24')


def overlay(seg, w, s):
    st = int(s * SR); en = min(len(seg), st + len(w)); seg[st:en] += w[:en - st]


def main():
    out = Path(sys.argv[1]); bgm_path = sys.argv[2]; ref_path = sys.argv[3]
    (out / 'one_shots').mkdir(parents=True, exist_ok=True)
    ref, _ = sf.read(ref_path, dtype='float32')
    target = loud_db(ref)
    cands = {
        'S3_Plasma_Blaster': s3_plasma_blaster(1.0),
        'S3L_Plasma_Blaster_x1.5': s3_plasma_blaster(1.5),
    }
    print('name,len_to_-40dB_s,peak,loud_vs_target_dB,2-6kHz_share_dB,3-5kHz_share_dB,6-14kHz_share_dB,re_rise_dB')
    for k, w in cands.items():
        w = w * 10 ** ((target - loud_db(w)) / 20)
        if np.abs(w).max() > 0.95:
            w *= 0.95 / np.abs(w).max()
        cands[k] = w
        write(out / 'one_shots' / f'{k}.wav', w)
        print(k, round(length_to(w), 3), round(float(np.abs(w).max()), 3), round(loud_db(w) - target, 1), round(band_share(w, 2000, 6000), 1),
              round(band_share(w, 3000, 5000), 1), round(band_share(w, 6000, 14000), 1), round(re_rise(w), 1), sep=',')

    bgm, _ = sf.read(bgm_path, dtype='float32')
    seg0 = bgm[int(55.0 * SR):int(61.7 * SR)]
    seg0 = seg0 * min(1, 0.42 / max(0.01, np.abs(seg0).max()))
    gain = 0.65 * 10 ** (LEVEL_DB / 20)
    gap = np.zeros((int(0.45 * SR), 2), dtype=np.float32)
    chunks = []
    for w in cands.values():
        v = seg0.copy()
        for s in (1.05, 2.75, 4.45):
            overlay(v, w * gain, s)
        if np.abs(v).max() > 0.95:
            v *= 0.95 / np.abs(v).max()
        chunks += [v, gap]
    wav = out / '_tmp_01.wav'
    write(wav, np.concatenate(chunks))
    subprocess.run(['afconvert', '-f', 'm4af', '-d', 'aac', '-b', '192000', str(wav),
                    str(out / '01_比較_BGM_A_55秒区間.m4a')], check=True)
    wav.unlink()


if __name__ == '__main__':
    main()


# ---- 段階A以降で共通化した部品・計測 ----

def saw(t, f0, f1, tau):
    ph = sweep_phase(t, f0, f1, tau) / (2 * np.pi)
    return 2 * (ph % 1.0) - 1


def wobble_plate(n, t, seed, count, lo, hi, base_decay, rate=22, depth=0.02):
    """短く揺れる金属の鳴り：周波数をわずかに揺らした非整数倍音。"""
    rng = np.random.default_rng(seed)
    y = np.zeros(n)
    for f in np.sort(rng.uniform(lo, hi, count)):
        dec = base_decay * (lo / f) ** 0.5 * rng.uniform(0.7, 1.3)
        ph = 2 * np.pi * f * t + (depth * f / rate) * np.sin(2 * np.pi * rate * t) + rng.uniform(0, 6.28)
        y += (lo / f) ** 0.6 * np.sin(ph) * np.exp(-t / dec)
    return y * -np.expm1(-t / 0.0004) / max(np.abs(y).max(), 1e-9)


def time_to(x, db):
    """ピークから db まで下がる時刻（主要部分の長さ）。"""
    e = np.sqrt(np.convolve((x ** 2).mean(1), np.ones(480) / 480, 'same'))[::48]
    d = 20 * np.log10(e / e.max() + 1e-9)
    pk = int(np.argmax(e))
    return (pk + int(np.argmax(d[pk:] < db))) / 1000


def re_rise20(x):
    """20ms 窓での持ち直し量。周期的な揺れを除いた「二段目の立ち上がり」の目安。"""
    e = np.sqrt(np.convolve((x ** 2).mean(1), np.ones(960) / 960, 'same'))[::48]
    db = 20 * np.log10(e / e.max() + 1e-9)
    seg = db[int(np.argmax(e)):]
    if (seg < -20).any():
        seg = seg[:int(np.argmax(seg < -20))]
    if len(seg) == 0:
        return 0.0
    return float((seg - np.minimum.accumulate(seg)).max())


def centroid(x):
    m = x.mean(1)
    F = np.abs(np.fft.rfft(m, 65536))
    f = np.fft.rfftfreq(65536, 1 / SR)
    return float((F * f).sum() / F.sum())


def match_loudness(w, target, offset_db=0.0, ceiling=0.95):
    w = w * 10 ** ((target + offset_db - loud_db(w)) / 20)
    if np.abs(w).max() > ceiling:
        w *= ceiling / np.abs(w).max()
    return w


def bgm_section(bgm, start=55.0, dur=6.7):
    seg = bgm[int(start * SR):int((start + dur) * SR)]
    return seg * min(1, 0.42 / max(0.01, np.abs(seg).max()))


def encode_m4a(mix, out_path, tmp_dir):
    wav = Path(tmp_dir) / '_tmp_encode.wav'
    write(wav, mix)
    subprocess.run(['afconvert', '-f', 'm4af', '-d', 'aac', '-b', '192000', str(wav), str(out_path)], check=True)
    wav.unlink()
