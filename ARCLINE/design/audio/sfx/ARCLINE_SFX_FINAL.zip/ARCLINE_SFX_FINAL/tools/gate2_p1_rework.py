"""ARCLINE 効果音 再制作計画 v1.0 Gate 2：P1 の4本（必殺技の発射 _r1）とA/B比較・攻撃の連結試聴。

Gate 1 で採用した F-01_power_strong_r1 の鋭さ・低域バランスを基準に、4機の役割を分ける。
ガン＝重砲（砲口の割れ目＋太い機械圧）、バン＝圧力射出（中域が軽快な空気・エネルギーの押し出し）、
モグ＝工業的破砕（歯車・ドリルの中域のザラつき）、コロ＝駆動弾（丸みと、走り出す予感の短い唸り）。
各ファイルは一音。衝撃波・転走・連鎖破砕などの現象音は発射音に入れない。
使い方: python gate2_p1_rework.py <出力先> <BGM A の wav> <ラウドネス基準の wav> <ARCLINE_SFX_FINAL/sounds> <Gate 1 の sounds>
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402
import soundfile as sf  # noqa: E402
from arcline_sfx_lib import (SR, LEVEL_DB, rms, env, sweep_phase, bp, lp, noise, sat, crush, metal_plate,  # noqa: E402
                             resonant_lp_sweep, finish, loud_db, write, overlay, time_to, re_rise20, centroid,
                             match_loudness, bgm_section, encode_m4a)
from gate1_p0_rework import export, share_below, share_band, peak_db  # noqa: E402
from phaseD_specials import s03_roll, s03_roll_fall  # noqa: E402

# Gate 1 で採用した改修案の再生補正（Gate 1 README 記載値）
GATE1_COMP = {'F-01_power_strong_r1': 4.1, 'I-04_Fracture_Hit_r1': 1.7, 'S-05_Core_Compression_r1': 0.2}


def plasma_layer(n, t, seed, f_start, f_end, tau, q, decay, drive=2.0):
    """F-01 系の噴射（急に閉じる共鳴フィルターに通したノイズ）。"""
    p = resonant_lp_sweep(noise(n, seed), f_start, f_end, tau, q)
    p = p / max(rms(p[:int(0.03 * SR)]), 1e-9) * env(t, 0.0003, decay, 1.2) * 0.4
    return sat(p, drive)


def sp_fire_gun_r1():
    """ガン「ドバシュンッ」重装・直撃：鋭い砲口の割れ目と、太い機械の圧力を同じ瞬間に。残響は短い。"""
    n = int(0.60 * SR); t = np.arange(n) / SR
    crack = sat(noise(n, 2001, 1500, 12000) * env(t, 0.0001, 0.0045, 1.0) * 0.5, 3)
    muzzle = sat(noise(n, 2002, 600, 3000) * env(t, 0.0002, 0.022, 1.1) * 0.5, 3.0)
    plasma = plasma_layer(n, t, 2003, 6000, 650, 0.028, 3.5, 0.063)
    barrel = sat(noise(n, 2004, 150, 700) * env(t, 0.0004, 0.060, 1.2) * 0.5, 2.8)
    body = sat(np.sin(sweep_phase(t, 190, 110, 0.007)) * env(t, 0.0004, 0.065, 1.3), 3.0)
    breech = metal_plate(n, t, 2005, 10, 700, 2800, 0.018)
    sub = np.sin(sweep_phase(t, 90, 55, 0.012)) * env(t, 0.0008, 0.060, 1.3)
    mono = 0.70 * crack + 0.75 * muzzle + 0.60 * plasma + 0.70 * barrel + 0.65 * body + 0.22 * breech + 0.85 * sub
    return finish(mono, t, 2006, rt60=0.32, predelay=0.006, lp_hz=5000, mix=0.12, harsh_cut=-5.0)


def sp_fire_ban_r1():
    """バン「バシュンッ」圧力射出：ガンより中域が軽快。空気とエネルギーが前へ押し出される。横への広がり（S-01）は先取りしない。"""
    n = int(0.50 * SR); t = np.arange(n) / SR
    crack = sat(noise(n, 2101, 1800, 12000) * env(t, 0.0001, 0.0035, 1.0) * 0.5, 3)
    plasma = plasma_layer(n, t, 2102, 7500, 800, 0.026, 3.5, 0.065)
    push = resonant_lp_sweep(noise(n, 2103), 3500, 700, 0.012, 2.5)
    push = sat(push / max(rms(push[:int(0.03 * SR)]), 1e-9) * env(t, 0.0008, 0.050, 1.2) * 0.4, 2.2)
    pneu = sat(noise(n, 2104, 400, 2500) * env(t, 0.0010, 0.050, 1.2) * 0.45, 2.2)
    body = sat(np.sin(sweep_phase(t, 260, 160, 0.005)) * env(t, 0.0004, 0.055, 1.3), 2.6)
    sub = np.sin(sweep_phase(t, 120, 75, 0.010)) * env(t, 0.0006, 0.035, 1.3)
    mono = 0.75 * crack + 0.75 * plasma + 0.65 * push + 0.55 * pneu + 0.45 * body + 0.25 * sub
    return finish(mono, t, 2105, rt60=0.28, predelay=0.005, lp_hz=5500, mix=0.12, harsh_cut=-5.0, width=0.06)


def sp_fire_mogu_r1():
    """モグ「ガシュンッ」工業的破砕：歯車・ドリルが構造物を食い破るような中域のザラつき。丸い低音にしない。"""
    n = int(0.50 * SR); t = np.arange(n) / SR
    crack = sat(noise(n, 2201, 1500, 11000) * env(t, 0.0001, 0.0040, 1.0) * 0.5, 3)
    plasma = plasma_layer(n, t, 2202, 6500, 800, 0.023, 3.0, 0.050)
    # 歯車・ドリル：約72Hzの鋭い脈で刻んだ中域ノイズ。粒に分かれず一音のザラつきに融けるよう、速く短く
    teeth = np.exp(-((t * 72) % 1.0) / 0.18)
    drill = bp(noise(n, 2203), 700, 3500) * teeth * env(t, 0.0003, 0.050, 1.2)
    drill = crush(sat(drill / max(rms(drill[:int(0.04 * SR)]), 1e-9) * 0.4, 3.0), 5, 2)
    drill = keep_rms(bp(drill, 600, 4500), drill)
    grit = crush(sat(noise(n, 2204, 900, 3500) * env(t, 0.0003, 0.055, 1.15) * 0.5, 3.2), 6, 2)
    grit = keep_rms(bp(grit, 700, 4500), grit)
    knock = sat(np.sin(sweep_phase(t, 300, 170, 0.005)) * env(t, 0.0003, 0.040, 1.3), 2.8)
    clank = metal_plate(n, t, 2205, 12, 900, 3800, 0.012)
    sub = np.sin(sweep_phase(t, 110, 70, 0.008)) * env(t, 0.0006, 0.030, 1.3)
    mono = 0.70 * crack + 0.45 * plasma + 0.50 * drill + 0.40 * grit + 0.55 * knock + 0.20 * clank + 0.20 * sub
    return finish(mono, t, 2206, rt60=0.28, predelay=0.005, lp_hz=5000, mix=0.12, harsh_cut=-5.5)


def sp_fire_koro_r1():
    """コロ「ボシュッ」駆動弾の射出：モグより丸い。走り出す予感を短い回転の唸りで添える（転走音そのものは入れない）。"""
    n = int(0.50 * SR); t = np.arange(n) / SR
    crack = sat(lp(noise(n, 2301, 1200, 9000), 6000) * env(t, 0.0003, 0.0045, 1.0) * 0.5, 2.5)
    plasma = plasma_layer(n, t, 2302, 5000, 600, 0.026, 2.5, 0.058, drive=1.8)
    body = sat(np.sin(sweep_phase(t, 210, 120, 0.008)) * env(t, 0.0006, 0.065, 1.3), 1.6)
    puff = sat(noise(n, 2303, 200, 900) * env(t, 0.0008, 0.045, 1.2) * 0.45, 1.8)
    # 走り出す予感：回転の脈が 18Hz→34Hz へ速まる短い唸り。約0.15秒で消える
    rate = 18 + 16 * np.clip(t / 0.10, 0, 1)
    spin = (0.5 + 0.5 * np.cos(2 * np.pi * np.cumsum(rate) / SR)) ** 2
    whirr = lp(noise(n, 2304), 900) * spin * env(t, 0.010, 0.070, 1.4)
    whirr /= max(rms(whirr[:int(0.12 * SR)]), 1e-9)
    sub = np.sin(sweep_phase(t, 100, 62, 0.010)) * env(t, 0.0008, 0.050, 1.3)
    mono = 0.55 * crack + 0.65 * plasma + 0.70 * body + 0.55 * puff + 0.12 * whirr + 0.45 * sub
    return finish(mono, t, 2305, rt60=0.26, predelay=0.005, lp_hz=4000, mix=0.12, harsh_cut=-5.0)


def keep_rms(after, before):
    return after * rms(before) / max(rms(after), 1e-12)


def corr220(a, b):
    a = a[:int(0.22 * SR)].mean(1); b = b[:int(0.22 * SR)].mean(1)
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b)))


def main():
    out = Path(sys.argv[1]); bgm_path = sys.argv[2]; ref_path = sys.argv[3]
    final = Path(sys.argv[4]); gate1 = Path(sys.argv[5])
    (out / 'sounds').mkdir(parents=True, exist_ok=True)
    rd = lambda p: sf.read(p, dtype='float64')[0]  # noqa: E731
    target = loud_db(rd(ref_path))
    machines = ('gun', 'ban', 'mogu', 'koro')
    old = {m: rd(final / 'SP_fire' / f'SP_fire_{m}.wav') for m in machines}
    fns = {'gun': sp_fire_gun_r1, 'ban': sp_fire_ban_r1, 'mogu': sp_fire_mogu_r1, 'koro': sp_fire_koro_r1}
    new, comp, play = {}, {}, {}
    for m in machines:
        off = loud_db(old[m]) - target  # 旧版と同じ役割の音量
        new[m], comp[m] = export(fns[m](), target, off)
        play[m] = new[m] * 10 ** (comp[m] / 20)
        write(out / 'sounds' / f'SP_fire_{m}_r1.wav', new[m])
        print(f'{m}: 役割の音量 {off:+.1f}dB、書き出しピーク {peak_db(new[m]):.1f}dBFS、再生補正 {comp[m]:+.1f}dB')
    (out / '再生補正.json').write_text(json.dumps({f'SP_fire_{m}_r1': round(comp[m], 1) for m in machines},
                                              ensure_ascii=False, indent=2), encoding='utf-8')

    ref = rd(gate1 / 'F-01_power_strong_r1.wav') * 10 ** (GATE1_COMP['F-01_power_strong_r1'] / 20)
    print('name,main_-20dB_s,below100Hz_%,200-2kHz_%,800-4kHz_%,centroid_Hz,first30ms_energy_%,re_rise20_dB')

    def row(name, w):
        e = (w ** 2).sum(1)
        print(name, time_to(w, -20), round(100 * share_below(w, 100)), round(100 * share_band(w, 200, 2000)),
              round(100 * share_band(w, 800, 4000)), round(centroid(w)), round(100 * e[:int(0.03 * SR)].sum() / e.sum()),
              round(re_rise20(w), 1), sep=',')
    row('基準 F-01_power_strong_r1', ref)
    for m in machines:
        row(f'{m}(旧)', old[m])
        row(f'{m}_r1', play[m])
    print('冒頭220msの波形相関（旧）  ', ' '.join(f'{a}-{b}:{corr220(old[a], old[b]):.2f}'
                                         for i, a in enumerate(machines) for b in machines[i + 1:]))
    print('冒頭220msの波形相関（改修案）', ' '.join(f'{a}-{b}:{corr220(play[a], play[b]):.2f}'
                                         for i, a in enumerate(machines) for b in machines[i + 1:]))

    # ---- 試聴（同じBGM区間・同じ時刻・同じ音量） ----
    bgm = rd(bgm_path)
    seg0 = bgm_section(bgm)
    G = 0.65 * 10 ** (LEVEL_DB / 20)
    d = lambda v: 10 ** (v / 20)  # noqa: E731
    M = lambda w, off=0.0: match_loudness(w, target, off, ceiling=99)  # noqa: E731
    i01 = M(rd(final / 'I_impact/I-01_Hard_Contact.wav'))
    i02 = rd(final / 'I_impact/I-02_Armor_Slam.wav')
    i05 = rd(final / 'I_impact/I-05_Pressure_Impact.wav')
    d01 = rd(final / 'D_debris/D-01_Debris_Break.wav')
    s01 = rd(final / 'S_special/S-01_Pressure_Wave.wav')
    i04 = rd(gate1 / 'I-04_Fracture_Hit_r1.wav') * 10 ** (GATE1_COMP['I-04_Fracture_Hit_r1'] / 20)
    roll1 = rd(final / 'S_special/S-03_Rolling_Drive_1.2s.wav')
    roll2 = M(s03_roll(1.4, 1210), -4.0)  # 段階Dと同じ 1.4 秒の再転走
    fall = rd(final / 'S_special/S-03_Roll_Fall.wav')

    def scene(events):
        v = seg0.copy()
        for at, w, g in events:
            overlay(v, w * G * g, at)
        return v

    def mogu_seq(fire):
        ev = []
        for base in (1.05, 3.80):
            ev += [(base, fire, 1)] + [(base + 0.80 + 0.22 * k, i04, d(g)) for k, g in enumerate((-3.0, -2.0, 0.0))]
            ev += [(base + 0.80 + 0.44 + 0.015, d01, d(-3))]
        return ev

    scenes = [
        ('4機の発射 旧', scene([(1.00, old['gun'], 1), (2.30, old['ban'], 1), (3.60, old['mogu'], 1), (4.90, old['koro'], 1)])),
        ('4機の発射 新', scene([(1.00, play['gun'], 1), (2.30, play['ban'], 1), (3.60, play['mogu'], 1), (4.90, play['koro'], 1)])),
        ('ガン 新', scene([(1.05, play['gun'], 1), (2.05, i02, 1), (2.065, d01, d(-3)), (3.60, play['gun'], 1), (4.60, i02, 1)])),
        ('バン 新', scene([(1.05, play['ban'], 1), (1.85, i05, 1), (1.855, s01, 1),
                         (3.60, play['ban'], 1), (4.40, i05, 1), (4.405, s01, 1)])),
        ('モグ 新', scene(mogu_seq(play['mogu']))),
        ('コロ 新', scene([(0.60, play['koro'], 1), (1.30, i01, d(-10)), (1.30, roll1, 1), (2.50, fall, 1),
                         (2.85, i01, d(-10)), (2.85, roll2, 1), (4.25, i02, 1)])),
    ]
    gap = np.zeros((int(0.45 * SR), 2))
    chunks, pos = [], 0.0
    for label, v in scenes:
        pk = float(np.abs(v).max())
        print(f'scene {label}: start {pos:5.2f}s peak {pk:.3f}' + ('  -> normalized' if pk > 0.95 else ''))
        if pk > 0.95:
            v = v * 0.95 / pk
        chunks += [v, gap]
        pos += (len(v) + len(gap)) / SR
    encode_m4a(np.concatenate(chunks), out / '01_AB比較と攻撃の連結_BGM_A_55秒区間.m4a', out)


if __name__ == '__main__':
    main()
