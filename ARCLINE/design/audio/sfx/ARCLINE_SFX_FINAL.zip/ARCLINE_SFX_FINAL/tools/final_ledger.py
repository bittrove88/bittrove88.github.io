"""ARCLINE_SFX_FINAL の台帳と再生補正の一覧を作る（再制作計画 v1.0 §9）。
sounds/ の最終版 40 本と、archive/ に移した旧版をまとめて台帳にする。
使い方: python final_ledger.py <ARCLINE_SFX_FINAL フォルダ>
"""
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gate1_ledger import INFO, describe  # noqa: E402

# 再制作で差し替えた音：ファイル名 → (再生補正 dB, 計画書の区分)
REVISED = {
    'F-01_power_strong': (4.1, 'P0 再制作済み（Gate 1）'),
    'I-04_Fracture_Hit': (1.7, 'P0 再制作済み（Gate 1）'),
    'S-05_Core_Compression': (0.2, 'P0 再制作済み（Gate 1）'),
    'SP_fire_gun': (4.6, 'P1 再制作済み（Gate 2）'),
    'SP_fire_ban': (2.6, 'P1 再制作済み（Gate 2）'),
    'SP_fire_mogu': (1.7, 'P1 再制作済み（Gate 2）'),
    'SP_fire_koro': (3.0, 'P1 再制作済み（Gate 2）'),
}
COLS = ['ファイル', 'ID', '版', '状態', '計画書の区分', '使うイベント・用途', '尺_秒', '主要部分_秒（-20dBまで）',
        'ピーク_dBFS', '再生補正_dB', '100Hz未満のエネルギー_%', '場所', 'SHA-256', '備考']


def main():
    final = Path(sys.argv[1])
    rows, comp = [], {}
    for p in sorted((final / 'sounds').glob('*/*.wav')):
        sid, ev, pri, note = INFO[p.stem]
        c, pri = REVISED.get(p.stem, (0.0, pri))
        if p.stem in REVISED:
            note = '再制作計画 v1.0 の改修版（ピーク -3dBFS で書き出し）。旧版は archive/20261102/'
        comp[str(p.relative_to(final))] = c
        rows.append({'ファイル': p.name, 'ID': sid, '版': 'r1' if p.stem in REVISED else 'r0', '使うイベント・用途': ev,
                     '計画書の区分': pri, '状態': '最終版（未実装）', '再生補正_dB': f'{c:+.1f}', **describe(p, final),
                     '備考': note})
    for p in sorted((final / 'archive').glob('*/sounds/*/*.wav')):
        sid, ev, _, _ = INFO[p.stem]
        rows.append({'ファイル': p.name, 'ID': sid, '版': 'r0', '使うイベント・用途': ev, '計画書の区分': '旧版',
                     '状態': 'archive（旧版。実装しない）', '再生補正_dB': '+0.0', **describe(p, final),
                     '備考': f'{p.parts[-4]} に再制作版へ差し替え'})
    with open(final / '台帳.csv', 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=COLS)
        w.writeheader()
        w.writerows(rows)
    (final / '再生補正.json').write_text(json.dumps(comp, ensure_ascii=False, indent=2), encoding='utf-8')
    print(len(rows), 'rows,', sum(1 for v in comp.values() if v), 'files need gain compensation')


if __name__ == '__main__':
    main()
