import sys, numpy as np, soundfile as sf
SR=48000
bgm,_=sf.read(sys.argv[1],dtype='float32')
ed=[250,500,1000,2000,3000,4000,6000,9000,14000]
def bands(x):
  F=np.abs(np.fft.rfft(x*np.hanning(len(x))))**2;f=np.fft.rfftfreq(len(x),1/SR)
  return np.array([10*np.log10(F[(f>=a)&(f<c)].sum()+1e-12) for a,c in zip(ed[:-1],ed[1:])])
W=int(.06*SR)
def bgm_bands(start):
  seg=bgm[int(start*SR):int((start+6.7)*SR)].mean(1);seg=seg*min(1,.42/max(.01,np.abs(bgm[int(start*SR):int((start+6.7)*SR)]).max()))
  return np.mean([bands(seg[i:i+W]) for i in range(0,len(seg)-W,W)],axis=0), np.max([bands(seg[i:i+W]) for i in range(0,len(seg)-W,W)],axis=0)
print('bands',['%d-%d'%(a,c) for a,c in zip(ed[:-1],ed[1:])])
for st in (55.0,127.5):
  mean,mx=bgm_bands(st)
  print('== BGM',st,'shot(0.65x, first 60ms) minus BGM mean / minus BGM loudest frame')
  for p in sys.argv[2:]:
    w,_=sf.read(p,dtype='float32');b=bands(w[:W].mean(1)*.65)
    print(p.split('/')[-1][:22].ljust(22),' mean:',' '.join('%+4d'%v for v in b-mean),' | max:',' '.join('%+4d'%v for v in b-mx))
