"""5曲の戦闘BGMを、ゲームと同じ固定音量（BGM A 55秒区間の試聴と同じゲイン）で比べる。"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np, soundfile as sf
from arcline_sfx_lib import SR, k_weight
d = Path(sys.argv[1])
names = {'A': 'bgm_battle_a_original', 'B': 'bgm_battle_b_original', 'C': 'bgm_battle_c_original',
         '大ボス': 'bgm_boss_original', '最終ボス': 'bgm_final_boss_original'}
a, _ = sf.read(d / 'bgm_battle_a_original.wav', dtype='float64')
gA = 0.42 / np.abs(a[int(55 * SR):int(61.7 * SR)]).max()
print(f'固定ゲイン {gA:.4f}（BGM A 55秒区間の試聴と同じ）')
def frames(x):
    p = np.sum(k_weight(x) ** 2, axis=1); w = 4800
    return -0.691 + 10 * np.log10(np.convolve(p, np.ones(w) / w, 'valid')[::2400] + 1e-12)
def band_db(x, lo, hi, W=4800):
    m = x.mean(1); out = []
    for i in range(0, len(m) - W, W):
        F = np.abs(np.fft.rfft(m[i:i + W] * np.hanning(W))) ** 2; f = np.fft.rfftfreq(W, 1 / SR)
        out.append(10 * np.log10(F[(f >= lo) & (f < hi)].sum() + 1e-12))
    return np.median(out)
res = {}
for k, n in names.items():
    x, _ = sf.read(d / f'{n}.wav', dtype='float64'); x = x * gA
    L = frames(x); win = int(6.7 * 10)  # 6.7 秒（0.05 秒刻み × 134）
    ma = np.convolve(10 ** (L / 10), np.ones(2 * win) / (2 * win), 'valid'); i = int(np.argmax(ma)); t0 = i * 0.05
    sec = x[int(t0 * SR):int((t0 + 6.7) * SR)]
    res[k] = (np.median(L), 10 * np.log10(ma.max()), t0, band_db(sec, 1000, 4000), band_db(sec, 4000, 8000))
base = res['A']
print('曲,全体の典型(中央値),最も厚い6.7秒,その開始秒,1-4kHz(最も厚い区間),4-8kHz(最も厚い区間)  ※A との差')
for k, (med, mx, t0, b1, b2) in res.items():
    print(f'{k},{med - base[0]:+.1f},{mx - base[1]:+.1f},{t0:.1f},{b1 - base[3]:+.1f},{b2 - base[4]:+.1f}')
