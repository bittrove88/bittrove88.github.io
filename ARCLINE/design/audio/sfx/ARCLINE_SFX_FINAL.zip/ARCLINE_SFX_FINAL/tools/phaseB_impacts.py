"""ARCLINE 効果音 段階B：着弾・被弾 I-01〜I-05。

発射（F系）は前へ抜ける押し出し、着弾は「当たって止まる」接触感で作る。下降するフィルターの掃引は使わず、
立ち上がり直後の硬い接触と、短く消える破片・火花で構成する。自機・敵の区別はしない（何がどう当たったかで選ぶ）。
使い方: python phaseB_impacts.py <出力先> <BGM A の wav> <ラウドネス基準の wav>
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402
import soundfile as sf  # noqa: E402
from arcline_sfx_lib import (SR, LEVEL_DB, rms, env, sweep_phase, bp, lp, noise, sat, crush, crackle,  # noqa: E402
                             metal_plate, wobble_plate, resonant_lp_sweep, finish, s3_plasma_blaster,
                             loud_db, band_share, length_to, write, overlay, time_to, re_rise20, centroid,
                             match_loudness, bgm_section, encode_m4a)


def grains(n, t, seed, rate, tau, lo, hi, grain_ms=(2, 6)):
    """破砕の粒：長さがばらつく短いノイズ粒を、密度を減らしながら散らす。"""
    rng = np.random.default_rng(seed)
    y = np.zeros(n)
    src = noise(n, seed + 1, lo, hi)
    pos = 0
    while pos < n:
        gap = rng.exponential(SR / (rate * np.exp(-pos / SR / tau) + 1e-9))
        pos += int(max(gap, 1))
        if pos >= n:
            break
        g = int(rng.uniform(*grain_ms) * SR / 1000)
        seg = slice(pos, min(n, pos + g))
        y[seg] += src[seg] * np.hanning(seg.stop - seg.start) * rng.uniform(0.3, 1.0)
    return y / max(np.abs(y).max(), 1e-9)


def i01_hard_contact(dur=0.40):
    """I-01 ハード・コンタクト「バチッ／パシュッ」：小〜中の弾が装甲や地面に当たる短い固い衝撃。基準点。"""
    n = int(dur * SR); t = np.arange(n) / SR
    click = sat(noise(n, 801, 1000, 8000) * env(t, 0.0001, 0.0035, 1.0) * 0.5, 2.5)
    tick = metal_plate(n, t, 802, 8, 1400, 4200, 0.012)
    body = sat(np.sin(sweep_phase(t, 230, 125, 0.004)) * env(t, 0.0003, 0.060, 1.3), 2.0)
    thud = sat(noise(n, 803, 200, 1600) * env(t, 0.0002, 0.050, 1.2) * 0.45, 2.4)
    spark = crackle(n, t, 804, 1800, 0.050, 2000, 8000)
    mono = 0.85 * click + 0.30 * tick + 0.75 * body + 0.85 * thud + 0.16 * spark
    return finish(mono, t, 805, rt60=0.30, predelay=0.004, lp_hz=4000, mix=0.15, harsh_cut=-4.0)


def i02_armor_slam(dur=0.55):
    """I-02 アーマー・スラム「ドガッ」：厚い装甲を押し込む低く固い着弾。強い一撃が止まる瞬間。"""
    n = int(dur * SR); t = np.arange(n) / SR
    click = sat(noise(n, 811, 800, 6000) * env(t, 0.0002, 0.0035, 1.0) * 0.5, 2.5)
    press = sat(np.sin(sweep_phase(t, 95, 44, 0.015)) * env(t, 0.0006, 0.095, 1.25), 2.2)
    punch = sat(noise(n, 812, 140, 1100) * env(t, 0.0003, 0.060, 1.2) * 0.5, 2.8)
    armor = wobble_plate(n, t, 813, 16, 220, 1900, 0.070, rate=17, depth=0.012)
    crackk = bp(crush(noise(n, 814) * 0.3, 5, 3), 1500, 5000) * env(t, 0.0004, 0.020, 1.1)
    crackk /= max(rms(crackk[:int(0.02 * SR)]), 1e-9)
    mono = 0.85 * click + 1.00 * press + 0.90 * punch + 0.40 * armor + 0.10 * crackk
    return finish(mono, t, 815, rt60=0.40, predelay=0.006, lp_hz=3000, mix=0.16, harsh_cut=-4.0,
                  width_band=(500, 4000))


def i03_plasma_snap(dur=0.45):
    """I-03 プラズマ・スナップ「バジンッ」：発光する弾が接触／近接起爆した瞬間の鋭いエネルギー破裂。余韻は浅い。"""
    n = int(dur * SR); t = np.arange(n) / SR
    click = sat(noise(n, 821, 1500, 10000) * env(t, 0.0001, 0.003, 1.0) * 0.5, 3.0)
    # 細かな倍音：強い変調の FM を一瞬だけ鳴らし、電気の唸り（120Hz）を重ねる
    pc = 2 * np.pi * 880 * t
    idx = 1.0 + 7.0 * np.exp(-t / 0.010)
    buzz = np.sin(pc + idx * np.sin(3.7 * pc)) * (1 + 0.5 * np.sign(np.sin(2 * np.pi * 120 * t)))
    buzz = bp(buzz, 600, 6000) * env(t, 0.0003, 0.060, 1.2)
    buzz /= max(np.abs(buzz).max(), 1e-9)
    mid = sat(noise(n, 822, 600, 2500) * env(t, 0.0002, 0.055, 1.2) * 0.45, 2.6)
    spark = crackle(n, t, 823, 5000, 0.045, 1500, 10000)
    pop = sat(np.sin(sweep_phase(t, 170, 85, 0.005)) * env(t, 0.0004, 0.050, 1.3), 2.0)
    mono = 0.75 * click + 0.35 * buzz + 0.80 * mid + 0.26 * spark + 0.65 * pop
    return finish(mono, t, 825, rt60=0.25, predelay=0.004, lp_hz=5000, mix=0.12, harsh_cut=-4.5)


def i04_fracture_hit(dur=0.50):
    """I-04 フラクチャー・ヒット「ガシャッ」：硬い構造材が圧力でひび割れる鋭い破砕の手応え。破片が落ち続けない。"""
    n = int(dur * SR); t = np.arange(n) / SR
    click = sat(noise(n, 831, 1000, 8000) * env(t, 0.0001, 0.003, 1.0) * 0.5, 2.8)
    tear = sat(noise(n, 832, 700, 5000) * env(t, 0.0003, 0.070, 1.2) * 0.5, 3.5)
    tear = crush(tear * 0.8, 6, 2) * (0.4 + 0.6 * grains(n, t, 833, 900, 0.080, 300, 8000))
    snapgr = grains(n, t, 834, 500, 0.080, 1200, 6000, grain_ms=(1, 4))
    metal = metal_plate(n, t, 835, 14, 700, 4800, 0.020)
    punch = sat(np.sin(sweep_phase(t, 125, 60, 0.008)) * env(t, 0.0004, 0.060, 1.3), 2.0)
    mono = 0.60 * click + 0.55 * tear + 0.22 * snapgr + 0.20 * metal + 0.95 * punch
    return finish(mono, t, 836, rt60=0.30, predelay=0.005, lp_hz=4500, mix=0.14, harsh_cut=-5.5)


def i05_pressure_impact(dur=0.50):
    """I-05 プレッシャー・インパクト「ヴォンッ」：空気・空間が一瞬押しつぶされる圧力。高い金属片の尾は抑える。"""
    n = int(dur * SR); t = np.arange(n) / SR
    whomp = resonant_lp_sweep(noise(n, 841), 2600, 260, 0.030, 2.2)
    whomp = sat(whomp / max(rms(whomp[:int(0.04 * SR)]), 1e-9) * env(t, 0.0010, 0.070, 1.2) * 0.4, 2.0)
    press = sat(np.sin(sweep_phase(t, 100, 58, 0.020)) * env(t, 0.0015, 0.080, 1.3), 1.8)
    burst = sat(noise(n, 842, 400, 2000) * env(t, 0.0004, 0.025, 1.2) * 0.45, 2.4)
    click = lp(noise(n, 843, 600, 5000), 4000) * env(t, 0.0003, 0.003, 1.0)
    mono = 0.90 * whomp + 0.85 * press + 0.60 * burst + 0.30 * click
    return finish(mono, t, 845, rt60=0.30, predelay=0.006, lp_hz=2500, mix=0.12, harsh_cut=-5.0,
                  width_band=(400, 3000))


IMPACT_DELAY = 0.80  # 発射から着弾までの間隔（試聴用の仮値）


def main():
    out = Path(sys.argv[1]); bgm_path = sys.argv[2]; ref_path = sys.argv[3]
    (out / 'one_shots').mkdir(parents=True, exist_ok=True)
    ref, _ = sf.read(ref_path, dtype='float32')
    target = loud_db(ref)
    fire = match_loudness(s3_plasma_blaster(1.5), target)
    impacts = {
        'I-01_Hard_Contact': i01_hard_contact(),
        'I-02_Armor_Slam': i02_armor_slam(),
        'I-03_Plasma_Snap': i03_plasma_snap(),
        'I-04_Fracture_Hit': i04_fracture_hit(),
        'I-05_Pressure_Impact': i05_pressure_impact(),
    }
    print('name,main_part_to_-20dB_s,len_to_-40dB_s,peak,loud_vs_target_dB,centroid_Hz,'
          'below250Hz_share_dB,3-5kHz_share_dB,6-14kHz_share_dB,re_rise20_dB')
    for k, w in impacts.items():
        w = match_loudness(w, target)
        impacts[k] = w
        write(out / 'one_shots' / f'{k}.wav', w)
        print(k, time_to(w, -20), round(length_to(w), 3), round(float(np.abs(w).max()), 3),
              round(loud_db(w) - target, 1), round(centroid(w)), round(band_share(w, 90, 250), 1),
              round(band_share(w, 3000, 5000), 1), round(band_share(w, 6000, 14000), 1), round(re_rise20(w), 1),
              sep=',')

    bgm, _ = sf.read(bgm_path, dtype='float32')
    seg0 = bgm_section(bgm)
    gain = 0.65 * 10 ** (LEVEL_DB / 20)
    gap = np.zeros((int(0.45 * SR), 2), dtype=np.float32)
    chunks = []
    for w in impacts.values():
        v = seg0.copy()
        for s in (1.05, 2.75, 4.45):
            overlay(v, fire * gain, s)
            overlay(v, w * gain, s + IMPACT_DELAY)
        if np.abs(v).max() > 0.95:
            v *= 0.95 / np.abs(v).max()
        chunks += [v, gap]
    encode_m4a(np.concatenate(chunks), out / '01_比較_BGM_A_55秒区間.m4a', out)


if __name__ == '__main__':
    main()
