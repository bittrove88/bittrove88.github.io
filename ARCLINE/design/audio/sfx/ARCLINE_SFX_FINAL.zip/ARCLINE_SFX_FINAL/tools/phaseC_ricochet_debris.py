"""ARCLINE 効果音 段階C：反射・跳弾 R-01、障害物の破壊 D-01。

R-01 は短い金属の立ち上がりとごく短い共鳴。通常の跳弾は同系統内で小さく音程・響きを変え、
リコだけ跳弾回数（growth 0〜3）に応じて密度・重さを少し増やす。
D-01 は実際に破壊が成立した時だけ鳴らす。前半の破断が主役、後半の粒状の破片は控えめ。
使い方: python phaseC_ricochet_debris.py <出力先> <BGM A の wav> <ラウドネス基準の wav>
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402
import soundfile as sf  # noqa: E402
from arcline_sfx_lib import (SR, LEVEL_DB, env, sweep_phase, bp, noise, sat, crush, metal_plate,  # noqa: E402
                             finish, s3_plasma_blaster, loud_db, band_share, length_to, write, overlay,
                             time_to, re_rise20, centroid, match_loudness, bgm_section, encode_m4a)
from phaseB_impacts import i01_hard_contact, i02_armor_slam, i04_fracture_hit  # noqa: E402


def r01_armor_ricochet(seed=0, pitch=1.0, growth=0, dur=0.32):
    """R-01 アーマー・リコシェ「キンッ／カンッ」：硬い金属に当たって向きが変わる瞬間。音程は感じても短く歌わない。"""
    n = int(dur * SR); t = np.arange(n) / SR
    rng = np.random.default_rng(900 + seed)
    g = growth
    click = sat(noise(n, 901 + seed, 1500, 10000) * env(t, 0.0001, 0.002 + 0.0005 * g, 1.0) * 0.5, 3.0)
    # 非整数比の短い共鳴。高い成分ほど早く消して、チャイムやコインの音にしない
    f0 = 1650 * pitch * (1 - 0.04 * g)
    ratios = [1.0, 1.47, 2.09, 2.56, 3.21] + list(rng.uniform(1.2, 3.4, 2 * g))
    ring = np.zeros(n)
    for i, r in enumerate(ratios):
        f = f0 * r * rng.uniform(0.97, 1.03)
        dec = 0.034 * (1 + 0.15 * g) / (1 + 0.5 * min(i, 4))
        ring += (1 / (1 + min(i, 4)) ** 0.6) * np.sin(2 * np.pi * f * t + rng.uniform(0, 6.28)) * np.exp(-t / dec)
    ring *= -np.expm1(-t / 0.0002)
    ring /= max(np.abs(ring).max(), 1e-9)
    body = sat(np.sin(sweep_phase(t, 300, 160, 0.004)) * env(t, 0.0003, 0.020 + 0.008 * g, 1.3), 2.0)
    grit = noise(n, 902 + seed, 800, 4000) * env(t, 0.0002, 0.012 + 0.003 * g, 1.1)
    mono = 0.42 * click + 0.60 * ring + (0.25 + 0.20 * g) * body + (0.18 + 0.08 * g) * grit
    return finish(mono, t, 905 + seed, rt60=0.22 + 0.04 * g, predelay=0.004, lp_hz=5000, mix=0.12,
                  harsh_cut=-4.5)


def debris(n, t, seed, start, end, rate, tau):
    """小さな破片がぶつかる粒：短い金属の点音を、密度と音量を下げながら散らす。"""
    rng = np.random.default_rng(seed)
    y = np.zeros(n)
    pos = start
    while pos < end:
        pos += rng.exponential(1 / (rate * np.exp(-(pos - start) / tau) + 1e-9))
        if pos >= end:
            break
        i = int(pos * SR)
        m = min(n - i, int(0.03 * SR))
        tt = np.arange(m) / SR
        ping = sum(np.sin(2 * np.pi * rng.uniform(1800, 5500) * tt + rng.uniform(0, 6.28)) *
                   np.exp(-tt / rng.uniform(0.004, 0.010)) for _ in range(2))
        ping += 0.6 * rng.standard_normal(m) * np.exp(-tt / 0.002)
        y[i:i + m] += ping * rng.uniform(0.3, 1.0) * np.exp(-(pos - start) / (tau * 1.5))
    return y / max(np.abs(y).max(), 1e-9)


def d01_debris_break(dur=0.85):
    """D-01 デブリ・ブレイク「ガシャァッ、チャラッ」：構造物が割れ、小さな破片が一瞬散る。精密な破壊感。"""
    n = int(dur * SR); t = np.arange(n) / SR
    crack = sat(noise(n, 951, 800, 9000) * env(t, 0.0002, 0.006, 1.0) * 0.5, 3.0)
    breakk = crush(sat(noise(n, 952, 200, 3000) * env(t, 0.0004, 0.090, 1.2) * 0.5, 3.0), 7, 2)
    snap = metal_plate(n, t, 953, 16, 600, 5000, 0.035)
    low = sat(np.sin(sweep_phase(t, 110, 55, 0.010)) * env(t, 0.0005, 0.060, 1.3), 2.0)
    bits = debris(n, t, 954, 0.035, 0.55, 75, 0.15)
    rattle = bp(noise(n, 955), 1500, 6000) * env(t, 0.004, 0.12, 1.0) * 0.25
    mono = 0.80 * crack + 0.85 * breakk + 0.30 * snap + 0.75 * low + 0.28 * bits + 0.10 * rattle
    return finish(mono, t, 956, rt60=0.35, predelay=0.006, lp_hz=4500, mix=0.16, harsh_cut=-5.0)


def mix_pad(*parts):
    n = max(len(p) for p, _ in parts)
    out = np.zeros((n, 2))
    for p, g in parts:
        out[:len(p)] += p * g
    return out


def report(name, w, target):
    print(name, time_to(w, -20), time_to(w, -30), round(length_to(w), 3), round(float(np.abs(w).max()), 3),
          round(loud_db(w) - target, 1), round(centroid(w)), round(band_share(w, 3000, 5000), 1),
          round(re_rise20(w), 1), sep=',')


def main():
    out = Path(sys.argv[1]); bgm_path = sys.argv[2]; ref_path = sys.argv[3]
    (out / 'one_shots').mkdir(parents=True, exist_ok=True)
    ref, _ = sf.read(ref_path, dtype='float32')
    target = loud_db(ref)
    fire = match_loudness(s3_plasma_blaster(1.5), target)
    i01 = match_loudness(i01_hard_contact(), target)
    i02 = match_loudness(i02_armor_slam(), target)
    i04 = match_loudness(i04_fracture_hit(), target)

    print('name,main_part_to_-20dB_s,to_-30dB_s,len_to_-40dB_s,peak,loud_vs_target_dB,centroid_Hz,'
          '3-5kHz_share_dB,re_rise20_dB')
    # 通常の跳弾：同系統内の小さな変化（音程 ±1 半音程度と響きの違い）。跳弾は着弾より 2dB 控えめ
    normal = {}
    for v, (seed, pitch) in enumerate([(0, 1.0), (1, 0.945), (2, 1.06)], 1):
        w = match_loudness(r01_armor_ricochet(seed, pitch, 0), target, -2.0)
        normal[v] = w
        write(out / 'one_shots' / f'R-01_Ricochet_v{v}.wav', w)
        report(f'R-01_v{v}', w, target)
    # リコ：跳弾 1〜4 回目。密度・重さと音量を少しずつ増やす
    rico = {}
    for k in range(4):
        w = match_loudness(r01_armor_ricochet(0, 1.0, k), target, -2.4 + 0.5 * k, ceiling=0.99)
        rico[k + 1] = w
        write(out / 'one_shots' / f'R-01_Rico_bounce{k + 1}.wav', w)
        report(f'R-01_Rico_{k + 1}', w, target)
    rico_final = match_loudness(mix_pad((i01, 0.6), (i02, 0.8)), target, 1.0)
    write(out / 'one_shots' / 'I-01_I-02_Rico_final_blend.wav', rico_final)
    report('Rico_final(I-01+I-02)', rico_final, target)
    d01 = match_loudness(d01_debris_break(), target)
    write(out / 'one_shots' / 'D-01_Debris_Break.wav', d01)
    report('D-01', d01, target)

    bgm, _ = sf.read(bgm_path, dtype='float32')
    seg0 = bgm_section(bgm)
    gain = 0.65 * 10 ** (LEVEL_DB / 20)
    d01_overlap = 10 ** (-3 / 20)  # 着弾と重なる時は主音を着弾に譲る
    gap = np.zeros((int(0.45 * SR), 2), dtype=np.float32)
    scenes = []
    # 場面1：通常の跳弾（発射→跳弾→着弾）×3、跳弾は毎回少し違う
    v = seg0.copy()
    for (s, k) in zip((1.05, 2.75, 4.45), (1, 2, 3)):
        overlay(v, fire * gain, s)
        overlay(v, normal[k] * gain, s + 0.50)
        overlay(v, i01 * gain, s + 1.00)
    scenes.append(v)
    # 場面2：リコ（発射→跳弾4回→重めの最終着弾）
    v = seg0.copy()
    overlay(v, fire * gain, 0.80)
    for k, s in zip(range(1, 5), (1.45, 2.15, 2.85, 3.55)):
        overlay(v, rico[k] * gain, s)
    overlay(v, rico_final * gain, 4.35)
    scenes.append(v)
    # 場面3：破壊なし（I-04のみ）→ 破壊あり（I-04＋D-01）→ ガンの破壊（I-02＋D-01）
    v = seg0.copy()
    for s, hit, brk in ((1.05, i04, False), (2.75, i04, True), (4.45, i02, True)):
        overlay(v, fire * gain, s)
        overlay(v, hit * gain, s + 0.80)
        if brk:
            overlay(v, d01 * gain * d01_overlap, s + 0.815)
    scenes.append(v)
    chunks = []
    for v in scenes:
        if np.abs(v).max() > 0.95:
            v *= 0.95 / np.abs(v).max()
        chunks += [v, gap]
    encode_m4a(np.concatenate(chunks), out / '01_比較_BGM_A_55秒区間.m4a', out)


if __name__ == '__main__':
    main()
