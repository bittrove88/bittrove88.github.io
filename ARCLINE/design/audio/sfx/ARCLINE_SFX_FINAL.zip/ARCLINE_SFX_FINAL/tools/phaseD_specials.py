"""ARCLINE 効果音 段階D：必殺技の固有現象音 S-01〜S-06、F-01 の変奏、10機の必殺技の組み合わせ。

必殺技の個性は「F-01 の変奏（発射）＋共通の着弾 I 系＋実際に起きる現象の S 系」で作る。
タイミングは現行 game/dist/combat.js の値（ハナ 0/0.18/0.36 秒、モグ 0.22 秒間隔、コロ最長 3 秒の転走、
ソラ 8 分裂、リコ最大 4 回跳弾、ユイ 0.6 秒の吸引→圧縮）に合わせる。飛翔時間などは試聴用の仮の値。
使い方: python phaseD_specials.py <出力先> <BGM A の wav> <ラウドネス基準の wav>
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402
import soundfile as sf  # noqa: E402
from arcline_sfx_lib import (SR, LEVEL_DB, rms, env, sweep_phase, bp, hp, lp, noise, sat, crush, crackle,  # noqa: E402
                             resonant_lp_sweep, finish, s3_plasma_blaster, loud_db, band_share, length_to,
                             write, overlay, time_to, re_rise20, centroid, match_loudness, bgm_section,
                             encode_m4a)
from phaseB_impacts import (grains, i01_hard_contact, i02_armor_slam, i03_plasma_snap,  # noqa: E402
                            i04_fracture_hit, i05_pressure_impact)
from phaseC_ricochet_debris import r01_armor_ricochet, d01_debris_break, mix_pad  # noqa: E402


# ---- F-01 の変奏 ----

def f01v(stretch=1.5, pitch=1.0, weight=0.0, bright=0.0, energy=0.0, grit=0.0, seed=0):
    """F-01（S3L）の変奏。既定値のとき s3_plasma_blaster(1.5) と同じ音になる。
    pitch：噴射と低音の高さ、weight：低音の重さ、bright：破裂音と高域の鋭さ（負で丸く）、
    energy：電気の唸りの密度、grit：機構のザラつき。"""
    k = stretch
    n = int((0.45 + 0.25 * (k - 1)) * SR); t = np.arange(n) / SR
    crack = sat(noise(n, 301 + seed, 1800, 12000) * env(t, 0.0001, 0.0035, 1.0) * 0.5, 3)
    plasma = resonant_lp_sweep(noise(n, 302 + seed), 7500 * pitch, 700 * pitch, 0.020 * k, 3.5)
    plasma = sat(plasma / max(rms(plasma[:int(0.03 * SR)]), 1e-9) * env(t, 0.0003, 0.045 * k, 1.2) * 0.4, 2.0)
    sizzle = bp(crush(noise(n, 303 + seed) * 0.3, 4, 6), 2000, 8000) * env(t, 0.0005, 0.050 * k, 1.1)
    sizzle /= max(rms(sizzle[:int(0.04 * SR)]), 1e-9)
    pl = pitch * (1 - 0.15 * weight)
    thump = sat(np.sin(sweep_phase(t, 150 * pl, 60 * pl, 0.008 * k)) *
                env(t, 0.0005, 0.050 * k * (1 + 0.3 * weight), 1.3), 2.0)
    mono = (0.85 + 0.3 * bright) * crack + 0.80 * plasma + 0.14 * (1 + bright) * sizzle + 0.80 * (1 + weight) * thump
    if energy:
        pc = 2 * np.pi * 240 * pitch * t
        buzz = np.sin(pc + (1 + 5 * np.exp(-t / 0.012)) * np.sin(1.41 * pc))
        buzz = bp(buzz, 400, 4000) * env(t, 0.0004, 0.040 * k, 1.2)
        mono = mono + 0.30 * energy * buzz / max(np.abs(buzz).max(), 1e-9)
    if grit:
        g = bp(crush(noise(n, 304 + seed) * 0.4, 5, 3), 600, 3000) * env(t, 0.0004, 0.030 * k, 1.1)
        mono = mono + 0.25 * grit * g / max(rms(g[:int(0.03 * SR)]), 1e-9) * 0.3
    return finish(mono, t, 305 + seed, rt60=0.40 * k, predelay=0.006, lp_hz=5500 * (1 + 0.2 * bright), mix=0.20,
                  harsh_cut=-4.5 - 1.0 * max(bright, 0))


# ---- 必殺技の固有現象音 ----

def s01_pressure_wave(direction=1, dur=0.70):
    """S-01 プレッシャー・ウェーブ「ヴゥバンッ」：着弾点から前方へ空間が押し広がる一度きりの圧力変化。"""
    n = int(dur * SR); t = np.arange(n) / SR
    core = sat(np.sin(sweep_phase(t, 90, 52, 0.015)) * env(t, 0.0010, 0.060, 1.3), 1.8)
    push = resonant_lp_sweep(noise(n, 1001), 1800, 220, 0.030, 1.8)
    push = sat(push / max(rms(push[:int(0.04 * SR)]), 1e-9) * env(t, 0.0010, 0.080, 1.2) * 0.4, 2.0)
    st = finish(0.9 * core + 0.8 * push, t, 1005, rt60=0.35, predelay=0.008, lp_hz=3500, mix=0.14,
                harsh_cut=-5.0, width=0.0)
    # 横へ抜ける広がり：帯域が開きながら、左右無相関の成分が撃った方向へ流れる
    spread = np.column_stack([resonant_lp_sweep(noise(n, s), 500, 3200, 0.060, 0.9) for s in (1002, 1003)])
    spread *= env(t, 0.010, 0.140, 1.2)[:, None]
    spread /= max(rms(spread[:int(0.15 * SR)]), 1e-9)
    ramp = np.clip(t / 0.15, 0, 1)
    gl, gr = 1 - 0.45 * direction * ramp, 1 + 0.45 * direction * ramp
    st += 0.22 * np.abs(st).max() * spread * np.column_stack((gl, gr))
    st[-int(0.04 * SR):] *= np.linspace(1, 0, int(0.04 * SR))[:, None]
    return st


def s02_meteor_split(dur=0.50):
    """S-02 メテオ・スプリット「パシュッ」：上空で一つの弾が多数の粒へ分かれる細く広がる破裂。一度だけ。"""
    n = int(dur * SR); t = np.arange(n) / SR
    crack = sat(noise(n, 1101, 2500, 12000) * env(t, 0.0001, 0.003, 1.0) * 0.5, 3)
    spark = crackle(n, t, 1102, 7000, 0.070, 2500, 11000)
    fizz = noise(n, 1103, 3000, 10000) * env(t, 0.0003, 0.060, 1.1)
    air = lp(noise(n, 1104), 2500) * env(t, 0.0010, 0.090, 1.1)
    pop = sat(np.sin(sweep_phase(t, 260, 140, 0.004)) * env(t, 0.0003, 0.025, 1.3), 2.0)
    mono = 0.60 * crack + 0.30 * spark + 0.35 * fizz + 0.45 * air + 0.50 * pop
    return finish(mono, t, 1105, rt60=0.30, predelay=0.005, lp_hz=5000, mix=0.14, harsh_cut=-5.0,
                  width=0.25, width_band=(2500, 10000))


def s03_roll(dur, seed=1200):
    """S-03 ローリング・ドライブ「グルルル」：転走している間だけ鳴る低く細かい機械の駆動。長さは状態で決まる。"""
    n = int(dur * SR); t = np.arange(n) / SR
    rate = 22 * (1 + 0.06 * np.sin(2 * np.pi * 1.3 * t))
    puls = (0.5 + 0.5 * np.cos(2 * np.pi * np.cumsum(rate) / SR)) ** 3
    rumble = lp(noise(n, seed), 700) * (0.45 + 0.55 * puls)
    gear = sum(a * np.sin(2 * np.pi * f * t) for f, a in ((85, 1.0), (170, 0.4), (255, 0.2)))
    gear *= 0.6 + 0.4 * np.clip(lp(noise(n, seed + 1), 60) * 3, -1, 1)
    pebble = grains(n, t, seed + 2, 110, 10.0, 1000, 4500, grain_ms=(1, 3))
    mono = 0.80 * rumble / max(rms(rumble), 1e-9) + 0.35 * gear
    mono = lp(hp(mono, 70), 2500) + 0.30 * pebble * (0.45 + 0.55 * puls)
    fi, fo = int(0.03 * SR), int(0.06 * SR)
    mono[:fi] *= np.linspace(0, 1, fi)
    mono[-fo:] *= np.linspace(1, 0, fo)
    return np.column_stack((mono, mono))


def s03_roll_fall(dur=0.35):
    """S-03 の段差落下（roll-fall）：転走の唸りを止め、短く空気を切る質感に切り替える。"""
    n = int(dur * SR); t = np.arange(n) / SR
    cut = resonant_lp_sweep(noise(n, 1250), 900, 2600, 0.080, 1.5) * env(t, 0.010, 0.120, 1.2)
    cut = hp(cut, 300)
    fo = int(0.05 * SR)
    cut[-fo:] *= np.linspace(1, 0, fo)
    side = noise(n, 1251, 800, 4000) * env(t, 0.010, 0.10, 1.2) * 0.15 * rms(cut) / 1.0
    return np.column_stack((cut + side, cut - side))


def s04_gravity_pull(pull=0.60):
    """S-04 グラビティ・プル「ヴゥゥン」：周囲の空気が中心へ引き込まれ、密度が増していく 0.6 秒の吸引。"""
    n = int((pull + 0.03) * SR); t = np.arange(n) / SR
    prog = np.clip(t / pull, 0, 1)
    swell = prog ** 1.2
    end = int(pull * SR)
    swell[end:] *= np.linspace(1, 0, n - end)
    f = 220 + 80 * prog
    ph = 2 * np.pi * np.cumsum(f) / SR
    idx = 0.2 + 2.8 * prog
    tones = np.sin(ph + idx * np.sin(1.5 * ph)) + 0.5 * np.sin(2 * ph + idx * np.sin(2.98 * ph))
    suction = resonant_lp_sweep(noise(n, 1301), 400, 2400, pull / 2.5, 3.0)
    suction /= max(rms(suction), 1e-9)
    mono = lp(hp((0.5 * tones + 0.6 * suction) * swell, 150), 3200)
    # 外側に広がっていた成分が中心へ集まる（左右の幅を狭めていく）
    side = noise(n, 1302, 400, 3000) * (1 - prog) * swell * 0.3
    return np.column_stack((mono + side, mono - side))


def s05_core_compression(dur=0.60):
    """S-05 コア・コンプレッション「ドシュンッ」：空間が潰れる寸前から瞬間的に押し返す、短く高密度の衝撃。"""
    n = int(dur * SR); t = np.arange(n) / SR
    crack = sat(noise(n, 1401, 1200, 9000) * env(t, 0.0001, 0.004, 1.0) * 0.5, 3)
    boom = sat(np.sin(sweep_phase(t, 130, 42, 0.012)) * env(t, 0.0006, 0.090, 1.25), 2.4)
    blast = resonant_lp_sweep(noise(n, 1402), 5000, 400, 0.025, 3.0)
    blast = sat(blast / max(rms(blast[:int(0.03 * SR)]), 1e-9) * env(t, 0.0003, 0.070, 1.2) * 0.4, 2.5)
    pc = 2 * np.pi * 240 * t
    dense = np.sin(pc + (1 + 5 * np.exp(-t / 0.015)) * np.sin(1.41 * pc)) * env(t, 0.0004, 0.050, 1.2)
    mono = 0.45 * crack + 1.00 * boom + 0.85 * blast + 0.30 * dense
    return finish(mono, t, 1405, rt60=0.38, predelay=0.006, lp_hz=3500, mix=0.16, harsh_cut=-4.5)


def s06_pinpoint_break(dur=0.30):
    """S-06 ピンポイント・ブレイク「キィンッ」：狙いが一点に合った瞬間の短く硬い手応え。3〜5kHz は避けて芯を置く。"""
    n = int(dur * SR); t = np.arange(n) / SR
    rng = np.random.default_rng(1501)
    modes = sum(a * np.sin(2 * np.pi * f * t + rng.uniform(0, 6.28)) * np.exp(-t / d)
                for f, a, d in ((2350, 1.0, 0.045), (6370, 0.35, 0.020), (9160, 0.15, 0.010)))
    modes *= -np.expm1(-t / 0.0002)
    tick = noise(n, 1502, 1500, 9000) * env(t, 0.0001, 0.0015, 1.0)
    mid = sat(noise(n, 1503, 600, 2000) * env(t, 0.0002, 0.018, 1.2) * 0.45, 2.4)
    mono = 0.55 * modes + 0.40 * tick + 0.60 * mid
    return finish(mono, t, 1505, rt60=0.25, predelay=0.004, lp_hz=6000, mix=0.10, harsh_cut=-6.0, width=0.15)


def i03_airburst(dur=0.50):
    """I-03 の近接起爆の変奏（ヒバリ）：接触の硬い立ち上がりを除き、空中で光が弾けて広がる質感にする。"""
    n = int(dur * SR); t = np.arange(n) / SR
    pc = 2 * np.pi * 880 * t
    buzz = np.sin(pc + (1.0 + 7.0 * np.exp(-t / 0.012)) * np.sin(3.7 * pc)) * \
        (1 + 0.5 * np.sign(np.sin(2 * np.pi * 120 * t)))
    buzz = bp(buzz, 600, 6000) * env(t, 0.0008, 0.060, 1.2)
    buzz /= max(np.abs(buzz).max(), 1e-9)
    burst = sat(noise(n, 1601, 400, 3000) * env(t, 0.0010, 0.050, 1.2) * 0.45, 2.4)
    spark = crackle(n, t, 1602, 6000, 0.050, 1500, 10000)
    air = sat(np.sin(sweep_phase(t, 140, 70, 0.006)) * env(t, 0.0010, 0.045, 1.3), 2.0)
    mono = 0.40 * buzz + 0.85 * burst + 0.32 * spark + 0.70 * air
    return finish(mono, t, 1605, rt60=0.30, predelay=0.004, lp_hz=5000, mix=0.14, harsh_cut=-4.5,
                  width=0.30, width_band=(1000, 8000))


# ---- 補助 ----

def resample(x, ratio):
    """ratio > 1 で高く短く。小さな変化を付けるための簡易なピッチ変更。"""
    n = int(len(x) / ratio)
    src = np.arange(n) * ratio
    return np.column_stack([np.interp(src, np.arange(len(x)), x[:, c]) for c in range(2)])


def pan(x, p):
    """等パワーのパン（p：−1 左〜+1 右）。"""
    a = (p + 1) * np.pi / 4
    m = x.mean(1)
    return np.column_stack((m * np.cos(a), m * np.sin(a))) * np.sqrt(2)


def db(v):
    return 10 ** (v / 20)


def report(name, w, target):
    print(name, time_to(w, -20), round(length_to(w), 3), round(float(np.abs(w).max()), 3),
          round(loud_db(w) - target, 1), round(centroid(w)), round(band_share(w, 3000, 5000), 1),
          round(re_rise20(w), 1), sep=',')


def main():
    out = Path(sys.argv[1]); bgm_path = sys.argv[2]; ref_path = sys.argv[3]
    shots = out / 'one_shots'
    shots.mkdir(parents=True, exist_ok=True)
    ref, _ = sf.read(ref_path, dtype='float32')
    target = loud_db(ref)

    def M(w, off=0.0, name=None):
        w = match_loudness(w, target, off, ceiling=0.99)
        if name:
            write(shots / f'{name}.wav', w)
            report(name, w, target)
        return w

    print('name,main_part_to_-20dB_s,len_to_-40dB_s,peak,loud_vs_target_dB,centroid_Hz,3-5kHz_share_dB,'
          're_rise20_dB')
    assert np.array_equal(f01v(), s3_plasma_blaster(1.5)), 'F-01 の既定値が S3L と一致しない'

    # F-01 の威力3段階
    f_light = M(f01v(stretch=1.3, pitch=1.06, weight=-0.3), -2.0, 'F-01_power_light')
    f_mid = M(f01v(), 0.0, 'F-01_power_medium')
    f_strong = M(f01v(stretch=1.6, pitch=0.94, weight=0.4), 1.5, 'F-01_power_strong')
    # 10機の必殺技の発射（F-01 の変奏）
    fire = {
        'gun': M(f01v(stretch=1.6, pitch=0.85, weight=0.8), 1.0, 'SP_fire_gun'),
        'ban': M(f01v(stretch=1.5, pitch=0.92, weight=0.5), 0.5, 'SP_fire_ban'),
        'hibari': M(f01v(stretch=1.3, pitch=1.08, weight=-0.2, bright=0.3), 0.0, 'SP_fire_hibari'),
        'hana': [M(f01v(stretch=1.1, pitch=p, seed=s), -1.5, f'SP_fire_hana_{i + 1}')
                 for i, (p, s) in enumerate(((1.0, 0), (1.03, 10), (0.97, 20)))],
        'rin': M(f01v(stretch=1.4, pitch=1.15, bright=0.5), 0.0, 'SP_fire_rin'),
        'mogu': M(f01v(stretch=1.5, pitch=0.90, weight=0.6, grit=1.0), 0.5, 'SP_fire_mogu'),
        'koro': M(f01v(stretch=1.5, pitch=0.88, weight=0.6, bright=-0.4), 0.5, 'SP_fire_koro'),
        'sora': M(f01v(stretch=1.3, pitch=1.05), 0.0, 'SP_fire_sora'),
        'rico': M(f01v(stretch=1.2, pitch=1.12, bright=0.3), 0.0, 'SP_fire_rico'),
        'yui': M(f01v(stretch=1.5, pitch=0.95, energy=1.0), 0.0, 'SP_fire_yui'),
    }
    # 共通素材
    i01 = M(i01_hard_contact()); i02 = M(i02_armor_slam()); i03 = M(i03_plasma_snap())
    i04 = M(i04_fracture_hit()); i05 = M(i05_pressure_impact()); d01 = M(d01_debris_break())
    airburst = M(i03_airburst(), 0.0, 'I-03_airburst_variant_hibari')
    # 固有現象音
    s01 = M(s01_pressure_wave(), -2.0, 'S-01_Pressure_Wave')
    s02 = M(s02_meteor_split(), -1.0, 'S-02_Meteor_Split')
    roll1 = M(s03_roll(1.2, 1200), -4.0, 'S-03_Rolling_Drive_1.2s')
    roll2 = M(s03_roll(1.4, 1210), -4.0)
    fall = M(s03_roll_fall(), -5.0, 'S-03_Roll_Fall')
    s04 = M(s04_gravity_pull(), 0.0, 'S-04_Gravity_Pull')
    s05 = M(s05_core_compression(), 1.0, 'S-05_Core_Compression')
    s06 = M(s06_pinpoint_break(), 0.0, 'S-06_Pinpoint_Break')

    bgm, _ = sf.read(bgm_path, dtype='float32')
    seg0 = bgm_section(bgm)
    G = 0.65 * db(LEVEL_DB)
    rng = np.random.default_rng(77)

    def scene(events):
        v = seg0.copy()
        for at, w, g in events:
            overlay(v, w * G * g, at)
        return v

    scenes = {}
    scenes['power'] = scene([(1.05, f_light, 1), (2.75, f_mid, 1), (4.45, f_strong, 1)])
    # ガン：遮蔽物が壊れた一撃（I-02＋D-01）→ 壊れなかった一撃（I-02 のみ）
    scenes['gun'] = scene([(1.05, fire['gun'], 1), (2.05, i02, 1), (2.065, d01, db(-3)),
                           (3.60, fire['gun'], 1), (4.60, i02, 1)])
    # バン：I-05 と S-01 を一つの衝撃波として同時に
    scenes['ban'] = scene([(1.05, fire['ban'], 1), (1.85, i05, 1), (1.855, s01, 1),
                           (3.60, fire['ban'], 1), (4.40, i05, 1), (4.405, s01, 1)])
    # ヒバリ：接触前の空中起爆
    scenes['hibari'] = scene([(1.05, fire['hibari'], 1), (1.75, airburst, 1),
                              (3.60, fire['hibari'], 1), (4.30, airburst, 1)])
    # ハナ：0/0.18/0.36 秒の三連射と、実際の着弾数だけの I-01
    ev = []
    for base in (1.05, 3.60):
        for k, d in enumerate((0.0, 0.18, 0.36)):
            ev += [(base + d, fire['hana'][k], 1), (base + 0.80 + d, resample(i01, (0.97, 1.0, 1.03)[k]), db(-1.5))]
    scenes['hana'] = scene(ev)
    # リン：通常命中（I-03）→ クリティカル（I-03 を −3dB ＋ S-06）×2
    scenes['rin'] = scene([(1.05, fire['rin'], 1), (1.45, i03, 1),
                           (2.90, fire['rin'], 1), (3.30, i03, db(-3)), (3.30, s06, 1),
                           (4.75, fire['rin'], 1), (5.15, i03, db(-3)), (5.15, s06, 1)])
    # モグ：0.22 秒間隔の3回の破砕（ドン、ドン、ドガン）、最後に破壊成立の D-01
    ev = []
    for base in (1.05, 3.80):
        ev += [(base, fire['mogu'], 1)]
        for k, g in enumerate((-3.0, -2.0, 0.0)):
            ev += [(base + 0.80 + 0.22 * k, i04, db(g))]
        ev += [(base + 0.80 + 0.44 + 0.015, d01, db(-3))]
    scenes['mogu'] = scene(ev)
    # コロ：着地→転走 1.2 秒→段差落下→着地→再転走 1.4 秒→爆発で停止（I-02）
    scenes['koro'] = scene([(0.60, fire['koro'], 1), (1.30, i01, db(-10)), (1.30, roll1, 1),
                            (2.50, fall, 1), (2.85, i01, db(-10)), (2.85, roll2, 1), (4.25, i02, 1)])
    # ソラ：分裂 S-02 を一回、降る 8 発は小さな I-01（音程・定位・時刻を少しずつずらす）
    ev = []
    for base in (0.90, 3.70):
        ev += [(base, fire['sora'], 1), (base + 0.85, s02, 1)]
        for c in range(8):
            child = pan(resample(i01, rng.uniform(0.93, 1.08)), -0.7 + 1.4 * c / 7)
            ev += [(base + 1.40 + rng.uniform(0, 0.28), child, db(-11))]
    scenes['sora'] = scene(ev)
    # リコ：跳弾 1〜4 回目（段階C と同じ成長）→ 重めの最終着弾
    rico = [match_loudness(r01_armor_ricochet(0, 1.0, k), target, -2.4 + 0.5 * k, ceiling=0.99) for k in range(4)]
    rico_final = match_loudness(mix_pad((i01, 0.6), (i02, 0.8)), target, 1.0)
    scenes['rico'] = scene([(0.80, fire['rico'], 1)] + [(s, rico[k], 1) for k, s in enumerate((1.45, 2.15, 2.85, 3.55))] +
                           [(4.35, rico_final, 1)])
    # ユイ：接触 I-05（控えめ）＋吸引 S-04 0.6 秒 → 圧縮解放 S-05（主役）×2
    scenes['yui'] = scene([(0.70, fire['yui'], 1), (1.40, i05, db(-4)), (1.40, s04, 1), (2.00, s05, 1),
                           (3.60, fire['yui'], 1), (4.30, i05, db(-4)), (4.30, s04, 1), (4.90, s05, 1)])

    gap = np.zeros((int(0.45 * SR), 2), dtype=np.float32)
    files = {
        '01_必殺技_前半5機_BGM_A_55秒区間': ['power', 'gun', 'ban', 'hibari', 'hana', 'rin'],
        '02_必殺技_後半5機_BGM_A_55秒区間': ['mogu', 'koro', 'sora', 'rico', 'yui'],
    }
    for name, keys in files.items():
        chunks = []
        for k in keys:
            v = scenes[k]
            pk = float(np.abs(v).max())
            print(f'scene {k}: peak {pk:.3f}' + ('  -> normalized' if pk > 0.95 else ''))
            if pk > 0.95:
                v = v * 0.95 / pk
            chunks += [v, gap]
        encode_m4a(np.concatenate(chunks), out / f'{name}.m4a', out)


if __name__ == '__main__':
    main()
