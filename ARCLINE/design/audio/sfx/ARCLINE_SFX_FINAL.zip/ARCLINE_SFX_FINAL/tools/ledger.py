"""効果音の台帳（再制作計画 v1.0 §9）を、FINAL の現行版と各 Gate の改修案からまとめて作る。
使い方: python ledger.py <download_o フォルダ> <出力 CSV>
"""
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gate1_ledger import INFO, describe  # noqa: E402

# 各 Gate：フォルダ、改修案の状態、再生補正（旧版と同じ大きさで鳴らすための値）
GATES = [
    ('ARCLINE_SFX_rework_gate1', 'Gate 1 で採用（正式名への昇格は Gate 4）',
     {'F-01_power_strong_r1': 4.1, 'I-04_Fracture_Hit_r1': 1.7, 'S-05_Core_Compression_r1': 0.2}),
    ('ARCLINE_SFX_rework_gate2', 'Gate 2 で採用（正式名への昇格は Gate 4）', None),  # None：フォルダ内の 再生補正.json を読む
]
COLS = ['ファイル', 'ID', '版', '状態', '計画書の区分', '使うイベント・用途', '尺_秒', '主要部分_秒（-20dBまで）',
        'ピーク_dBFS', '再生補正_dB', '100Hz未満のエネルギー_%', '場所', 'SHA-256', '備考']


def main():
    base = Path(sys.argv[1]); out = Path(sys.argv[2])
    revised = {}  # 元のファイル名 → (r1 のパス, 状態, 再生補正, Gate フォルダ)
    for folder, status, comp in GATES:
        g = base / folder
        if not g.exists():
            continue
        comp = comp or json.loads((g / '再生補正.json').read_text(encoding='utf-8'))
        for p in sorted((g / 'sounds').glob('*_r1.wav')):
            revised[p.stem[:-3]] = (p, status, comp[p.stem], folder)
    rows = []
    for p in sorted((base / 'ARCLINE_SFX_FINAL' / 'sounds').glob('*/*.wav')):
        sid, ev, pri, note = INFO[p.stem]
        status = '現行（未実装）'
        if p.stem in revised:
            r1, st, _, folder = revised[p.stem]
            status = '現行（' + ('r1 を採用、Gate 4 で archive へ移す予定' if '採用' in st else 'r1 を審査中') + '）'
            note = f'改修案 {r1.name}（{folder}）'
        rows.append({'ファイル': p.name, 'ID': sid, '版': 'r0', '使うイベント・用途': ev, '計画書の区分': pri,
                     '状態': status, '再生補正_dB': '0.0', **describe(p, base), '備考': note})
    for orig, (p, st, comp, _) in revised.items():
        sid, ev, pri, _ = INFO[orig]
        rows.append({'ファイル': p.name, 'ID': sid, '版': 'r1', '使うイベント・用途': ev, '計画書の区分': pri,
                     '状態': st, '再生補正_dB': f'{comp:+.1f}', **describe(p, base),
                     '備考': f'{orig}.wav の改修案。ピーク -3dBFS で書き出し'})
    with open(out, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=COLS)
        w.writeheader()
        w.writerows(rows)
    print(len(rows), 'rows')


if __name__ == '__main__':
    main()
