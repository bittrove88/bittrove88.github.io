"""現在の最良版の全音について、5曲のBGMの最も厚い区間に対する帯域ごとの余裕を測る。
余裕 = 音の帯域ごとの最大30ms RMS（試聴と同じ音量） − BGMの同じ帯域の典型RMS（最も厚い6.7秒の100ms窓の中央値）。
使い方: python gate3_bgm5_check.py <dec フォルダ> <download_o> <出力CSV>
"""
import csv, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np, soundfile as sf
from scipy.signal import butter, sosfilt
from arcline_sfx_lib import SR, LEVEL_DB, k_weight
dec, base, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
G = 0.65 * 10 ** (LEVEL_DB / 20)
BANDS = [(250, 1000), (1000, 4000), (4000, 8000)]
bp = lambda x, lo, hi: sosfilt(butter(4, (lo, hi), 'bandpass', fs=SR, output='sos'), x)
# 現在の最良版（Gate 1・2 の採用分は r1 に置き換え、再生補正をかける）
final = base / 'ARCLINE_SFX_FINAL' / 'sounds'
g1, g2 = base / 'ARCLINE_SFX_rework_gate1' / 'sounds', base / 'ARCLINE_SFX_rework_gate2' / 'sounds'
comp = {'F-01_power_strong_r1': 4.1, 'I-04_Fracture_Hit_r1': 1.7, 'S-05_Core_Compression_r1': 0.2}
comp.update(json.loads((base / 'ARCLINE_SFX_rework_gate2' / '再生補正.json').read_text(encoding='utf-8')))
replaced = {k[:-3] for k in comp}
files = [p for p in sorted(final.glob('*/*.wav')) if p.stem not in replaced] + sorted(g1.glob('*.wav')) + sorted(g2.glob('*.wav'))
names = {'A': 'bgm_battle_a_original', 'B': 'bgm_battle_b_original', 'C': 'bgm_battle_c_original',
         '大ボス': 'bgm_boss_original', '最終ボス': 'bgm_final_boss_original'}
a, _ = sf.read(dec / 'bgm_battle_a_original.wav', dtype='float64')
gA = 0.42 / np.abs(a[int(55 * SR):int(61.7 * SR)]).max()
def loudest(x):
    p = np.sum(k_weight(x) ** 2, axis=1); w = int(6.7 * SR)
    c = np.convolve(p[::480], np.ones(w // 480), 'valid'); i = int(np.argmax(c)) * 480
    return x[i:i + w]
bgm_band = {}
for k, n in names.items():
    x, _ = sf.read(dec / f'{n}.wav', dtype='float64'); m = loudest(x * gA).mean(1)
    bgm_band[k] = [20 * np.log10(np.median([np.sqrt(np.mean(y[i:i + 4800] ** 2)) for i in range(0, len(y) - 4800, 4800)]) + 1e-12)
                   for y in (bp(m, lo, hi) for lo, hi in BANDS)]
rows = []
for p in files:
    w, _ = sf.read(p, dtype='float64'); w = w * 10 ** (comp.get(p.stem, 0) / 20) * G; m = w.mean(1)
    sfx = []
    for lo, hi in BANDS:
        y = bp(m, lo, hi) ** 2
        sfx.append(10 * np.log10(np.convolve(y, np.ones(1440) / 1440, 'valid').max() + 1e-12))
    row = {'音': p.name}
    for k in names:
        mg = [s - b for s, b in zip(sfx, bgm_band[k])]
        row[k] = max(mg)
        row[k + '_帯域'] = ['250Hz-1k', '1-4k', '4-8k'][int(np.argmax(mg))]
    rows.append(row)
with open(out, 'w', encoding='utf-8-sig', newline='') as fh:
    wr = csv.writer(fh)
    wr.writerow(['音'] + [f'{k}（最も出ている帯域の余裕dB）' for k in names] + ['最小の余裕dB', '最小の曲'])
    for r in rows:
        mn = min(names, key=lambda k: r[k])
        wr.writerow([r['音']] + [f"{r[k]:+.1f}（{r[k + '_帯域']}）" for k in names] + [f'{r[mn]:+.1f}', mn])
rows.sort(key=lambda r: min(r[k] for k in names))
print('余裕が小さい順（最も出ている帯域での余裕。A／最小）')
for r in rows[:14]:
    mn = min(names, key=lambda k: r[k])
    print(f"  {r['音']:<36} A {r['A']:+5.1f}（{r['A_帯域']}）  最小 {r[mn]:+5.1f}（{mn}, {r[mn + '_帯域']}）")
print('全体：A の余裕の中央値 %+.1f dB、各曲の中央値' % np.median([r['A'] for r in rows]),
      {k: round(float(np.median([r[k] for r in rows])), 1) for k in names})
print(len(rows), '音')
